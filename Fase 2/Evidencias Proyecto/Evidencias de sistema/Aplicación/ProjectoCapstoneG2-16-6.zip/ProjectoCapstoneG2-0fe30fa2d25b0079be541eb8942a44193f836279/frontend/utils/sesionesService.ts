import axiosInstance from "./AxiosInstance";

// Crear sesión
export const crearSesion = async (data: FormData) => {
  const response = await axiosInstance.post("/sesiones/", data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return response.data;
};

// Listar sesiones del entrenador autenticado
export const obtenerSesiones = async () => {
  const response = await axiosInstance.get("/sesiones/mias/");
  let data = response.data;
  if (data.results !== undefined) data = data.results;
  return Array.isArray(data) ? data : [];
};

// Actualizar sesión
export const actualizarSesion = async (id: number, data: FormData) => {
  const response = await axiosInstance.put(`/sesiones/${id}/`, data, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
  return response.data;
};

//Eliminar sesión
export const eliminarSesion = async (id: number) => {
  const response = await axiosInstance.delete(`/sesiones/${id}/`);
  return response.data;
};
