"use client";

import { useEffect, useState, useRef } from "react";
import axiosInstance from "@/utils/AxiosInstance";
import { ProtectedRoute } from "@/app/components/ProtectedRoute";
import React from "react";

type FormState = {
  id?: number;
  id_centro?: number;
  id_estado?: number;
  id_fase?: number;
  id_entrenador?: number;
  id_aroma?: number;
  id_canino?: number;
  nombre?: string;
  descripcion?: string;
  nombres?: string;
  apellidos?: string;
  email?: string;
  foto_can_base64?: string | null;
  nueva_foto_can_base64?: string;
  foto_entrenador_base64?: string | null;
  nueva_foto_entrenador_base64?: string;
  usuario?: {
    id?: number;
    username?: string;
    email?: string;
    password?: string;
    is_superuser?: boolean;
  } | null;
  entrenador_actual_id?: number | string | null;
  [key: string]: any;
};

type Modelo =
  | "centros"
  | "estados"
  | "entrenadores"
  | "fases"
  | "aromas"
  | "caninos";

const MODEL_LABELS: Record<Modelo, string> = {
  centros: "Centros",
  estados: "Estados Canino",
  entrenadores: "Entrenadores",
  fases: "Fases",
  aromas: "Aromas",
  caninos: "Caninos",
};

const MODEL_SINGULAR: Record<Modelo, string> = {
  centros: "Centro",
  estados: "Estado Canino",
  entrenadores: "Entrenador",
  fases: "Fase",
  aromas: "Aroma",
  caninos: "Canino",
};

function AdminPanelContent() {
  const [selectedModel, setSelectedModel] = useState<Modelo>("centros");
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<any | null>(null);
  const [form, setForm] = useState<FormState>({});
  const [fileMap, setFileMap] = useState<Record<string, File | null>>({});
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [centros, setCentros] = useState<any[]>([]);
  const [estados, setEstados] = useState<any[]>([]);
  const [entrenadores, setEntrenadores] = useState<any[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const endpoints: Record<Modelo, string> = {
    centros: "centros/",
    estados: "estados-canino/",
    entrenadores: "entrenadores/",
    fases: "fases/",
    aromas: "aromas/",
    caninos: "caninos/",
  };

  useEffect(() => {
    axiosInstance
      .get("centros/")
      .then((res) => setCentros(res.data.results ?? res.data))
      .catch(() => setCentros([]));
    axiosInstance
      .get("estados-canino/")
      .then((res) => setEstados(res.data.results ?? res.data))
      .catch(() => setEstados([]));
  }, []);

  useEffect(() => {
    if (selectedModel === "caninos") {
      axiosInstance
        .get("entrenadores/")
        .then((res) => setEntrenadores(res.data.results ?? res.data))
        .catch(() => setEntrenadores([]));
    }
  }, [selectedModel]);

  useEffect(() => {
    setLoading(true);
    axiosInstance
      .get(endpoints[selectedModel])
      .then((res) => {
        const results = Array.isArray(res.data)
          ? res.data
          : res.data.results ?? [];
        setData(results);
        setEditing(null);
        setForm({});
        setFileMap({});
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [selectedModel]);

  const handleDelete = async (id: number) => {
    if (!confirm("¿Seguro que deseas eliminar este registro?")) return;
    try {
      await axiosInstance.delete(`${endpoints[selectedModel]}${id}/`);
      setData((prev) =>
        prev.filter(
          (d) =>
            ![
              d.id,
              d.id_centro,
              d.id_estado,
              d.id_entrenador,
              d.id_fase,
              d.id_aroma,
              d.id_canino,
            ].includes(id)
        )
      );
    } catch (err) {
      alert("Error al eliminar el registro.");
      console.error(err);
    }
  };

  const handleEdit = (item: any) => {
    const flatItem: any = { ...item };

    if (selectedModel === "caninos") {
      if (item.centro && typeof item.centro === "object") {
        flatItem.centro_id = item.centro.id_centro ?? item.centro.id ?? "";
      }
      if (item.estado && typeof item.estado === "object") {
        flatItem.estado_id = item.estado.id_estado ?? item.estado.id ?? "";
      }
      if (item.entrenador_actual && typeof item.entrenador_actual === "object") {
        flatItem.entrenador_actual_id = item.entrenador_actual.id_entrenador ?? null;
      } else {
        flatItem.entrenador_actual_id = null;
      }
    }

    if (selectedModel === "entrenadores") {
      flatItem.usuario = item.usuario
        ? {
            id: item.usuario.id,
            username: item.usuario.username || "",
            email: item.usuario.email || "",
            is_superuser: item.usuario.is_superuser || false,
          }
        : null;
    }

    setEditing(item);
    setForm(flatItem);
    setFileMap({});
  };

  const handleInput = (key: string, value: any) => {
    setForm((prev: FormState) => ({ ...prev, [key]: value }));
  };

  const handleFileChange = (fieldName: string, file: File | null) => {
    if (!file) {
      setFileMap((prev) => ({ ...prev, [fieldName]: null }));
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result?.toString().split(",")[1];
      if (base64String) {
        setForm((prev: FormState) => ({
          ...prev,
          ...(selectedModel === "caninos"
            ? { nueva_foto_can_base64: base64String }
            : selectedModel === "entrenadores"
            ? { nueva_foto_entrenador_base64: base64String }
            : {}),
        }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const idKey =
      editing?.id_centro ||
      editing?.id_estado ||
      editing?.id_entrenador ||
      editing?.id_fase ||
      editing?.id_aroma ||
      editing?.id_canino ||
      editing?.id;

    const url = idKey
      ? `${endpoints[selectedModel]}${idKey}/`
      : endpoints[selectedModel];

    try {
      setLoading(true);
      const payload = { ...form };

      if (selectedModel === "caninos") {
        delete payload.foto_can;
        delete payload.foto_can_base64;
        if (payload.entrenador_actual_id === "") {
          payload.entrenador_actual_id = null;
        } else if (typeof payload.entrenador_actual_id === "string") {
          payload.entrenador_actual_id = payload.entrenador_actual_id
            ? Number(payload.entrenador_actual_id)
            : null;
        }
      }

      if (selectedModel === "entrenadores") {
        delete payload.foto_entrenador;
        delete payload.foto_entrenador_base64;

        const usuarioPayload: any = {};
        if (form.email) usuarioPayload.email = form.email;
        if (form.usuario?.username) usuarioPayload.username = form.usuario.username;
        if (form.usuario?.password) usuarioPayload.password = form.usuario.password;
        if (form.usuario?.is_superuser !== undefined) {
          usuarioPayload.is_superuser = form.usuario.is_superuser;
          usuarioPayload.is_staff = form.usuario.is_superuser;
        }

        if (editing && editing.usuario?.id) {
          usuarioPayload.id = editing.usuario.id;
        }
        payload.usuario = usuarioPayload;
      }

      if (editing) {
        await axiosInstance.put(url, payload);
      } else {
        await axiosInstance.post(url, payload);
      }

      const res = await axiosInstance.get(endpoints[selectedModel]);
      const results = Array.isArray(res.data)
        ? res.data
        : res.data.results ?? [];
      setData(results);
      setEditing(null);
      setForm({});
      setFileMap({});
    } catch (err: any) {
      console.error(err);
      const message = err.response?.data
        ? JSON.stringify(err.response.data)
        : "Error al guardar los datos.";
      alert(`Error: ${message}`);
    } finally {
      setLoading(false);
    }
  };

  const excludedKeys = [
    "id",
    "id_centro",
    "id_estado",
    "id_fase",
    "id_entrenador",
    "id_aroma",
    "id_canino",
    "foto_can",
    "foto_can_base64",
    "foto_entrenador",
    "foto_entrenador_base64",
    "usuario",
    "centro",
    "estado",
    "entrenador_actual",
    ...(selectedModel === "entrenadores" ? ["email"] : []),
  ];

  const currentKeys = Object.keys(data[0] || { nombre: "" }).filter(
    (k) => !excludedKeys.includes(k)
  );

  const displayValue = (val: any, field?: string): string => {
    if (val == null) return "—";
    if (typeof val === "string") return val;
    if (typeof val === "number") return String(val);

    if (typeof val === "object") {
      if (field?.includes("centro")) {
        return val.nombre_centro || val.nombre || "—";
      }
      if (field?.includes("estado")) {
        return val.descripcion || val.nombre || "—";
      }
      if (field?.includes("usuario")) {
        return val.username || val.email || "—";
      }
      if (field?.includes("entrenador_actual")) {
        return val.nombres && val.apellidos
          ? `${val.nombres} ${val.apellidos}`
          : val.nombres || val.apellidos || "Sin asignar";
      }
      return val.nombre || val.descripcion || "—";
    }

    return String(val);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-[144px] bottom-0 z-40 w-64 bg-white border-r shadow-md transform transition-transform duration-200 ease-in-out md:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold text-center py-2">Modelos</h2>
        </div>
        <nav className="px-3 py-4">
          <ul className="space-y-1">
            {Object.entries(MODEL_LABELS).map(([key, label]) => (
              <li key={key}>
                <button
                  onClick={() => {
                    setSelectedModel(key as Modelo);
                    setSidebarOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2.5 rounded text-sm transition-colors ${
                    selectedModel === key
                      ? "bg-green-100 font-semibold text-green-800"
                      : "hover:bg-gray-100"
                  }`}
                  aria-current={selectedModel === key ? "page" : undefined}
                >
                  {label}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>

      {/* Overlay móvil */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/40 md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Contenido principal */}
      <div className="flex-1 md:ml-64">
        <header className="sticky top-0 z-20 bg-white border-b md:hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <h1 className="text-lg font-bold text-gray-800">
              Gestión de {MODEL_LABELS[selectedModel]}
            </h1>
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md hover:bg-gray-100"
              aria-label="Abrir menú"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </button>
          </div>
        </header>

        <main className="p-4 md:p-6">
          <div className="max-w-7xl mx-auto">
            <h1 className="sr-only md:not-sr-only text-3xl font-bold capitalize mb-6">
              Gestión de {MODEL_LABELS[selectedModel]}
            </h1>

            {/* Formulario */}
            <section className="bg-white rounded-xl shadow-sm mb-6 overflow-hidden">
              <div className="p-4 md:p-6">
                <h2 className="text-xl font-semibold mb-4">
                  {editing ? "Editar" : "Crear"} {MODEL_SINGULAR[selectedModel]}
                </h2>

                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {currentKeys.map((k) => (
                      <div key={k} className="flex flex-col">
                        <label
                          htmlFor={`${k}-input`}
                          className="text-sm font-medium text-gray-700 mb-1 capitalize"
                        >
                          {k.replace(/_/g, " ")}
                        </label>
                        <input
                          id={`${k}-input`}
                          className="px-3 py-2 border border-gray-300 rounded-lg w-full min-w-0 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                          value={form[k] ?? ""}
                          onChange={(e) => handleInput(k, e.target.value)}
                        />
                      </div>
                    ))}

                    {selectedModel === "caninos" && (
                      <div className="flex flex-col">
                        <label
                          htmlFor="entrenador_actual_id"
                          className="text-sm font-medium text-gray-700 mb-1"
                        >
                          Entrenador actual
                        </label>
                        <select
                          id="entrenador_actual_id"
                          name="entrenador_actual_id"
                          value={form.entrenador_actual_id ?? ""}
                          onChange={(e) =>
                            handleInput("entrenador_actual_id", e.target.value || null)
                          }
                          className="px-3 py-2 border border-gray-300 rounded-lg w-full min-w-0 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                        >
                          <option value="">— Sin asignar —</option>
                          {entrenadores.map((ent) => (
                            <option key={ent.id_entrenador} value={ent.id_entrenador}>
                              {ent.nombres} {ent.apellidos}
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    {selectedModel === "entrenadores" && (
                      <>
                        <div className="flex flex-col">
                          <label
                            htmlFor="username-input"
                            className="text-sm font-medium text-gray-700 mb-1"
                          >
                            Username
                          </label>
                          <input
                            id="username-input"
                            className="px-3 py-2 border border-gray-300 rounded-lg w-full min-w-0 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            value={form.usuario?.username ?? ""}
                            onChange={(e) =>
                              setForm((prev: FormState) => ({
                                ...prev,
                                usuario: {
                                  ...prev.usuario,
                                  username: e.target.value,
                                },
                              }))
                            }
                          />
                        </div>

                        <div className="flex flex-col">
                          <label
                            htmlFor="email-input"
                            className="text-sm font-medium text-gray-700 mb-1"
                          >
                            Email
                          </label>
                          <input
                            id="email-input"
                            type="email"
                            className="px-3 py-2 border border-gray-300 rounded-lg w-full min-w-0 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            value={form.email ?? form.usuario?.email ?? ""}
                            onChange={(e) => {
                              const val = e.target.value;
                              setForm((prev: FormState) => ({
                                ...prev,
                                email: val,
                                usuario: {
                                  ...prev.usuario,
                                  email: val,
                                },
                              }));
                            }}
                          />
                        </div>

                        {!editing && (
                          <div className="md:col-span-2 flex flex-col">
                            <label
                              htmlFor="password-input"
                              className="text-sm font-medium text-gray-700 mb-1"
                            >
                              Contraseña
                            </label>
                            <input
                              id="password-input"
                              type="password"
                              className="px-3 py-2 border border-gray-300 rounded-lg w-full min-w-0 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                              value={form.usuario?.password ?? ""}
                              onChange={(e) =>
                                setForm((prev: FormState) => ({
                                  ...prev,
                                  usuario: {
                                    ...prev.usuario,
                                    password: e.target.value,
                                  },
                                }))
                              }
                            />
                          </div>
                        )}

                        {!editing && (
                          <div className="md:col-span-2 flex items-center">
                            <input
                              id="is-superuser"
                              type="checkbox"
                              className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                              checked={form.usuario?.is_superuser || false}
                              onChange={(e) =>
                                setForm((prev: FormState) => ({
                                  ...prev,
                                  usuario: {
                                    ...prev.usuario,
                                    is_superuser: e.target.checked,
                                    is_staff: e.target.checked,
                                  },
                                }))
                              }
                            />
                            <label htmlFor="is-superuser" className="ml-2 text-sm text-gray-700">
                              Superusuario (acceso total al sistema)
                            </label>
                          </div>
                        )}

                        <div className="md:col-span-2 flex flex-col">
                          <label className="text-sm font-medium text-gray-700 mb-2">
                            Foto del Entrenador
                          </label>
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="inline-flex items-center justify-center px-4 py-2.5 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 transition-colors"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 mr-2"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                              />
                            </svg>
                            Seleccionar foto
                          </button>

                          <input
                            type="file"
                            ref={fileInputRef}
                            accept="image/*"
                            className="hidden"
                            onChange={(e) =>
                              handleFileChange(
                                "foto_entrenador",
                                e.target.files?.[0] ?? null
                              )
                            }
                          />

                          {/* Vista previa inmediata de la nueva foto */}
                          {form.nueva_foto_entrenador_base64 && (
                            <div className="mt-3">
                              <img
                                src={`data:image/jpeg;base64,${form.nueva_foto_entrenador_base64}`}
                                alt="Vista previa"
                                className="w-24 h-24 object-cover rounded-lg border border-gray-200"
                              />
                            </div>
                          )}

                          {/* Foto actual (solo si no hay nueva) */}
                          {editing?.id_entrenador && !form.nueva_foto_entrenador_base64 && (
                            <div className="mt-3">
                              <img
                                src={`${process.env.NEXT_PUBLIC_DJANGO_URL}/api/entrenadores/${editing.id_entrenador}/foto/`}
                                alt="Foto"
                                className="w-24 h-24 object-cover rounded-lg border border-gray-200"
                                onError={(e) => {
                                  e.currentTarget.style.display = 'none';
                                  const parent = e.currentTarget.parentElement;
                                  if (parent) {
                                    const fallback = parent.querySelector('[data-fallback]');
                                    if (fallback) (fallback as HTMLElement).style.display = 'flex';
                                  }
                                }}
                              />
                              <div
                                data-fallback
                                className="w-full h-full flex items-center justify-center"
                                style={{ display: 'none' }}
                              >
                                <span className="text-gray-400 text-sm">Sin foto</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-3 pt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-5 py-2.5 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 disabled:opacity-60 disabled:cursor-not-allowed transition-colors min-w-[120px] flex justify-center"
                    >
                      {loading ? (
                        <svg
                          className="animate-spin h-5 w-5 text-white"
                          xmlns="http://www.w3.org/2000/svg"
                          fill="none"
                          viewBox="0 0 24 24"
                        >
                          <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                          ></circle>
                          <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                          ></path>
                        </svg>
                      ) : editing ? (
                        "Actualizar"
                      ) : (
                        "Crear"
                      )}
                    </button>
                    {editing && (
                      <button
                        type="button"
                        onClick={() => {
                          setEditing(null);
                          setForm({});
                          setFileMap({});
                        }}
                        className="px-5 py-2.5 bg-gray-200 text-gray-800 font-medium rounded-md hover:bg-gray-300 transition-colors min-w-[120px]"
                      >
                        Cancelar
                      </button>
                    )}
                  </div>
                </form>
              </div>
            </section>

            {/* Tabla / Lista */}
            <section className="bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 md:p-6">
                <h2 className="text-xl font-semibold mb-4">
                  Lista de {MODEL_LABELS[selectedModel]}
                </h2>

                {loading ? (
                  <div className="text-center py-8 text-gray-500">Cargando…</div>
                ) : data.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 italic">
                    No hay registros.
                  </div>
                ) : (
                  <>
                    {/* Mobile: Tarjetas */}
                    <div className="md:hidden space-y-4">
                      {data.map((item, idx) => (
                        <div key={idx} className="border rounded-lg p-4 bg-gray-50">
                          <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
                            {Object.entries(item)
                              .filter(([k]) => !excludedKeys.includes(k))
                              .map(([k, val]) => (
                                <React.Fragment key={k}>
                                  <dt className="font-medium text-gray-600 capitalize">
                                    {k.replace(/_/g, " ")}:
                                  </dt>
                                  <dd className="text-gray-900">
                                    {displayValue(val, k)}
                                  </dd>
                                </React.Fragment>
                              ))}
                            {item.entrenador_actual && (
                              <>
                                <dt className="font-medium text-gray-600">Entrenador actual:</dt>
                                <dd className="text-gray-900">
                                  {displayValue(item.entrenador_actual, "entrenador_actual")}
                                </dd>
                              </>
                            )}
                          </div>

                          {/* Foto si existe */}
                          {(item.foto_can_base64 || item.foto_entrenador_base64) && (
                            <div className="mt-3 flex justify-center">
                              <img
                                src={
                                  item.foto_can_base64
                                    ? `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/caninos/${item.id_canino}/foto/`
                                    : item.id_entrenador
                                    ? `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/entrenadores/${item.id_entrenador}/foto/`
                                    : ""
                                }
                                alt="Foto"
                                className="w-20 h-20 object-cover rounded-md border border-gray-200"
                                onError={(e) => (e.currentTarget.style.display = 'none')}
                              />
                            </div>
                          )}

                          {/* Acciones */}
                          <div className="mt-4 flex justify-end gap-2">
                            <button
                              onClick={() => handleEdit(item)}
                              className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                            >
                              Editar
                            </button>
                            <button
                              onClick={() =>
                                handleDelete(
                                  item.id_centro ||
                                    item.id_estado ||
                                    item.id_entrenador ||
                                    item.id_fase ||
                                    item.id_aroma ||
                                    item.id_canino ||
                                    item.id
                                )
                              }
                              className="px-3 py-1.5 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200"
                            >
                              Eliminar
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Desktop: Tabla */}
                    <div className="hidden md:block overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            {Object.keys(data[0] || { nombre: "" })
                              .filter((key) => !excludedKeys.includes(key))
                              .map((key) => (
                                <th
                                  key={key}
                                  scope="col"
                                  className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap"
                                >
                                  {key.replace(/_/g, " ")}
                                </th>
                              ))}
                            {selectedModel === "caninos" && (
                              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Entrenador actual
                              </th>
                            )}
                            <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Acciones
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {data.map((item, idx) => (
                            <tr key={idx} className="hover:bg-gray-50">
                              {Object.entries(item)
                                .filter(([k]) => !excludedKeys.includes(k))
                                .map(([k, val]) => (
                                  <td key={k} className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                                    {displayValue(val, k)}
                                  </td>
                                ))}

                              {selectedModel === "caninos" && (
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                                  {item.entrenador_actual
                                    ? displayValue(item.entrenador_actual, "entrenador_actual")
                                    : "—"}
                                </td>
                              )}

                              <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                                <div className="flex items-center justify-end gap-2">
                                  {(item.foto_can_base64 || item.foto_entrenador_base64) && (
                                    <img
                                      src={
                                        item.foto_can_base64
                                          ? `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/caninos/${item.id_canino}/foto/`
                                          : item.id_entrenador
                                          ? `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/entrenadores/${item.id_entrenador}/foto/`
                                          : ""
                                      }
                                      alt="Foto"
                                      className="w-10 h-10 object-cover rounded border"
                                      onError={(e) => (e.currentTarget.style.display = 'none')}
                                    />
                                  )}
                                  <button
                                    onClick={() => handleEdit(item)}
                                    className="text-blue-600 hover:text-blue-900"
                                    aria-label="Editar"
                                  >
                                    Editar
                                  </button>
                                  <button
                                    onClick={() =>
                                      handleDelete(
                                        item.id_centro ||
                                          item.id_estado ||
                                          item.id_entrenador ||
                                          item.id_fase ||
                                          item.id_aroma ||
                                          item.id_canino ||
                                          item.id
                                      )
                                    }
                                    className="text-red-600 hover:text-red-900 ml-3"
                                    aria-label="Eliminar"
                                  >
                                    Eliminar
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
}

export default function AdminPanelPage() {
  return (
    <ProtectedRoute adminOnly={true}>
      <AdminPanelContent />
    </ProtectedRoute>
  );
}