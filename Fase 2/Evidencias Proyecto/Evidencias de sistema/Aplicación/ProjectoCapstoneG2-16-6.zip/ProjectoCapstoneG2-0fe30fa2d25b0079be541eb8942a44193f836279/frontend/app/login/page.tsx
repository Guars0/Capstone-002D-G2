"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { refreshAuth } from "@/app/hooks/useAuthStore";

export default function LoginPage() {
  const [usernameOrEmail, setUsernameOrEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const router = useRouter();

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await axios.post("http://localhost:8000/api/token/", {
        username: usernameOrEmail,
        password,
      });

      const { access, refresh } = response.data;

      localStorage.setItem("access", access);
      localStorage.setItem("refresh", refresh);
      localStorage.setItem("username", usernameOrEmail);

      await refreshAuth();

      router.replace("/");
    } catch (err: unknown) {
      if (axios.isAxiosError(err)) {
        if (err.response?.status === 401) {
          setError("Credenciales inválidas");
        } else if (err.request) {
          setError("Servidor no disponible");
        } else {
          setError("Ocurrió un error inesperado");
        }
      } else if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("Ocurrió un error desconocido");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="flex items-center justify-center min-h-screen bg-cover bg-center bg-no-repeat px-4"
      style={{ backgroundImage: "url('/sagperrito.png')" }}
    >
      <div className="bg-white p-12 md:p-16 rounded-3xl shadow-xl w-full max-w-lg text-center -translate-y-16">
        <h1 className="text-5xl font-bold mb-10 text-gray-800">
          Inicio de sesión
        </h1>

        <form onSubmit={handleLogin} className="space-y-8">
          <input
            type="text"
            placeholder="Usuario o correo electrónico"
            value={usernameOrEmail}
            onChange={(e) => setUsernameOrEmail(e.target.value)}
            className="w-full px-5 py-4 border border-gray-300 rounded-full text-lg focus:outline-none focus:ring-2 focus:ring-[#328D56]"
            required
          />

          <input
            type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-5 py-4 border border-gray-300 rounded-full text-lg focus:outline-none focus:ring-2 focus:ring-[#328D56]"
            required
          />

          {error && <p className="text-red-600 text-base">{error}</p>}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#328D56] text-white py-4 rounded-full text-xl font-semibold hover:bg-[#2a7147] transition-colors disabled:opacity-50"
          >
            {loading ? "Ingresando..." : "Ingresar"}
          </button>
        </form>
      </div>
    </div>
  );
}
