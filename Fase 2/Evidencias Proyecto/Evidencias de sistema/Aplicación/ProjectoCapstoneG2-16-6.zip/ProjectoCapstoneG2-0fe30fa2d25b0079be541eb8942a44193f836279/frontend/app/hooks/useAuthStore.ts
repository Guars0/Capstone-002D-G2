"use client";

import { useSyncExternalStore } from "react";
import axiosInstance from "@/utils/AxiosInstance";

type AuthState = {
  isAuthenticated: boolean;
  username: string | null;
  isSuperUser: boolean;
  isLoading: boolean;
};

const DEFAULT_STATE: AuthState = Object.freeze({
  isAuthenticated: false,
  username: null,
  isSuperUser: false,
  isLoading: false,
});

let clientSnapshot: AuthState = { ...DEFAULT_STATE, isLoading: true };
let isInitialized = false;

async function updateAuthState() {
  try {
    const res = await axiosInstance.get("/usuarios/me/");
    clientSnapshot = {
      isAuthenticated: true,
      username: res.data.username || null,
      isSuperUser: res.data.is_superuser || res.data.is_staff || false,
      isLoading: false,
    };
  } catch (err) {
    clientSnapshot = { ...DEFAULT_STATE, isLoading: false };
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event("auth-update"));
  }
}

if (typeof window !== "undefined" && !isInitialized) {
  isInitialized = true;

  try {
    const currentPath = window.location.pathname || "/";

    if (currentPath === "/login") {
      clientSnapshot = { ...DEFAULT_STATE, isLoading: false };
      window.dispatchEvent(new Event("auth-update"));
    } else {
      updateAuthState();
    }
  } catch {
    clientSnapshot = { ...DEFAULT_STATE, isLoading: false };
    window.dispatchEvent(new Event("auth-update"));
  }
}

function getSnapshot(): AuthState {
  return clientSnapshot;
}

function getServerSnapshot(): AuthState {
  return DEFAULT_STATE;
}

function subscribe(callback: () => void) {
  if (typeof window === "undefined") return () => {};
  const handler = () => callback();
  window.addEventListener("auth-update", handler);
  return () => window.removeEventListener("auth-update", handler);
}

export function useAuthStore() {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

export async function refreshAuth() {
  clientSnapshot = { ...clientSnapshot, isLoading: true };
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event("auth-update"));
  }

  await updateAuthState();
}

export function logoutAuth() {
  clientSnapshot = {
    isAuthenticated: false,
    username: null,
    isSuperUser: false,
    isLoading: false,
  };

  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event("auth-update"));
  }
}
