// app/components/contacto.tsx
"use client";

import { FaFacebookF, FaXTwitter, FaPhone, FaInstagram } from "react-icons/fa6";
import { IoMail } from "react-icons/io5";

export default function Contacto() {
  return (
    <div 
      className="fixed right-0 top-1/2 -translate-y-1/2 z-50 flex flex-col gap-4 
                 bg-green-600 p-3 rounded-l-2xl shadow-xl
                 hidden md:flex"  
    >
      <a
        href="https://www.instagram.com/sagchile/"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-white text-green-700 w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition"
      >
        <FaInstagram size={20} />
      </a>

      <a
        href="https://www.facebook.com/sagchile"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-white text-green-700 w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition"
      >
        <FaFacebookF size={18} />
      </a>

      <a
        href="https://twitter.com/sagchile"
        target="_blank"
        rel="noopener noreferrer"
        className="bg-white text-green-700 w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition"
      >
        <FaXTwitter size={18} />
      </a>

      <a
        href="mailto:oirs@sag.gob.cl"
        className="bg-white text-green-700 w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition"
      >
        <IoMail size={20} />
      </a>

      <a
        href="tel:+6008181724"
        className="bg-white text-green-700 w-10 h-10 rounded-full flex items-center justify-center hover:scale-110 transition"
      >
        <FaPhone size={18} />
      </a>
    </div>
  );
}