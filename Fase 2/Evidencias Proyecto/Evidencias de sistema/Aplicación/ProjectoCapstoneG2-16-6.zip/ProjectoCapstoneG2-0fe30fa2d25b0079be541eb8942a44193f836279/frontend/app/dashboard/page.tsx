"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import Image from "next/image";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { ProtectedRoute } from "@/app/components/ProtectedRoute";
import axiosInstance from "@/utils/AxiosInstance";

type Canino = {
  id_canino: number;
  nombre: string;
  foto_can_base64?: string | null;
  estado: { descripcion: string } | null;
  fecha_nac?: string | null;
  inicio_ent?: string | null;
  fin_ent?: string | null;
  entrenador_actual?: { id_entrenador: number; nombres: string; apellidos: string } | null;
};

type Entrenador = { id_entrenador: number; nombres: string; apellidos: string };
type Fase = { id_fase: number; nombre: string };
type Aroma = { id_aroma: number; nombre: string };

type Sesion = {
  id_sesion: number;
  fecha_ini_local?: string;
  fecha_fin_local?: string;
  canino?: { id_canino: number; nombre: string } | null;
  entrenador?: Entrenador | null;
  fase?: Fase | null;
  aroma?: Aroma | null;
  duracion_min?: number | null;
  resultado?: string | null;
  puntuacion?: number | null;
};

const sesionesCache = new Map<number, Sesion[]>();

function DashboardContent() {
  const [loadingInitial, setLoadingInitial] = useState(true);
  const [loadingSesiones, setLoadingSesiones] = useState(false);
  const [caninos, setCaninos] = useState<Canino[]>([]);
  const [entrenadores, setEntrenadores] = useState<Entrenador[]>([]);
  const [fases, setFases] = useState<Fase[]>([]);
  const [aromas, setAromas] = useState<Aroma[]>([]);
  const [sesiones, setSesiones] = useState<Sesion[]>([]);
  const [selectedCanino, setSelectedCanino] = useState<number | null>(null);
  const [selectedEntrenadores, setSelectedEntrenadores] = useState<number[]>([]);
  const [selectedFases, setSelectedFases] = useState<number[]>([]);
  const [selectedAromas, setSelectedAromas] = useState<number[]>([]);
  const [selectedVariables, setSelectedVariables] = useState<string[]>(["entrenador"]);
  const [selectedChart, setSelectedChart] = useState<"bar" | "pie" | "line">("bar");

  const obtenerFotoUrl = (caninoId: number) =>
    `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/caninos/${caninoId}/foto/`;

  const cargarInicial = useCallback(async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    try {
      const [canRes, entRes, fasesRes, aromasRes] = await Promise.all([
        axiosInstance.get("caninos/", { signal: controller.signal }),
        axiosInstance.get("entrenadores/", { signal: controller.signal }),
        axiosInstance.get("fases/", { signal: controller.signal }),
        axiosInstance.get("aromas/", { signal: controller.signal }),
      ]);

      setCaninos(Array.isArray(canRes.data) ? canRes.data : canRes.data.results ?? []);
      setEntrenadores(Array.isArray(entRes.data) ? entRes.data : entRes.data.results ?? []);
      setFases(Array.isArray(fasesRes.data) ? fasesRes.data : fasesRes.data.results ?? []);
      setAromas(Array.isArray(aromasRes.data) ? aromasRes.data : aromasRes.data.results ?? []);
    } catch (err: any) {
      if (err.name === 'CanceledError') return;
      console.error("Error cargando datos iniciales:", err);
    } finally {
      clearTimeout(timeout);
      setLoadingInitial(false);
    }
  }, []);

  useEffect(() => {
    cargarInicial();
  }, [cargarInicial]);

  const cargarSesionesPorCanino = useCallback(async (caninoId: number) => {
    if (sesionesCache.has(caninoId)) {
      setSesiones(sesionesCache.get(caninoId)!);
      return;
    }

    setLoadingSesiones(true);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);

    try {
      const res = await axiosInstance.get(`sesiones/por_canino/?canino_id=${caninoId}`, {
        signal: controller.signal,
      });

      const caninoSel = caninos.find(c => c.id_canino === caninoId);
      const sesionesConCanino = (res.data as any[]).map((s: any) => {
        const entrenador = s.entrenador
          ? {
              id_entrenador: s.entrenador.id_entrenador,
              nombres: s.entrenador.nombre_completo.split(' ')[0] || "",
              apellidos: s.entrenador.nombre_completo.split(' ').slice(1).join(' ') || "",
            }
          : null;

        return {
          id_sesion: s.id_sesion,
          fecha_ini_local: s.fecha_ini,
          fecha_fin_local: s.fecha_fin,
          duracion_min: s.fecha_ini && s.fecha_fin
            ? Math.round((new Date(s.fecha_fin).getTime() - new Date(s.fecha_ini).getTime()) / 60000)
            : null,
          resultado: s.resultado || null,
          puntuacion: s.puntuacion || null,
          canino: caninoSel ? { id_canino: caninoSel.id_canino, nombre: caninoSel.nombre } : null,
          entrenador,
          fase: s.fase || null,
          aroma: s.aroma || null,
        };
      });

      sesionesCache.set(caninoId, sesionesConCanino);
      setSesiones(sesionesConCanino);
    } catch (err: any) {
      if (err.name === 'CanceledError') return;
      console.error(`Error cargando sesiones para canino ${caninoId}:`, err);
    } finally {
      clearTimeout(timeout);
      setLoadingSesiones(false);
    }
  }, [caninos]);

  useEffect(() => {
    if (selectedCanino !== null) {
      cargarSesionesPorCanino(selectedCanino);
    } else {
      setSesiones([]);
    }
  }, [selectedCanino, cargarSesionesPorCanino]);

  const sesionesFiltradas = useMemo(() => {
    return sesiones.filter((s) => {
      if (selectedEntrenadores.length > 0 && !selectedEntrenadores.includes(s.entrenador?.id_entrenador ?? -1)) return false;
      if (selectedFases.length > 0 && !selectedFases.includes(s.fase?.id_fase ?? -1)) return false;
      if (selectedAromas.length > 0 && !selectedAromas.includes(s.aroma?.id_aroma ?? -1)) return false;
      return true;
    });
  }, [sesiones, selectedEntrenadores, selectedFases, selectedAromas]);

  const chartData = useMemo(() => {
    const vars = selectedVariables.length ? selectedVariables : ["entrenador"];
    const grouped: Record<string, number> = {};

    sesionesFiltradas.forEach((s) => {
      const values = vars.map((v) => {
        switch (v) {
          case "canino": return s.canino?.nombre ?? "—";
          case "entrenador": return s.entrenador ? `${s.entrenador.nombres} ${s.entrenador.apellidos}` : "—";
          case "fase": return s.fase?.nombre ?? "—";
          case "aroma": return s.aroma?.nombre ?? "—";
          case "resultado": return s.resultado ?? "—";
          case "puntuacion": return String(s.puntuacion ?? "—");
          case "duracion": return `${s.duracion_min ?? 0} min`;
          case "mes": {
            const d = new Date(s.fecha_ini_local || "");
            return isNaN(d.getTime()) ? "—"
              : `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
          }
          default: return "—";
        }
      });
      const key = values.join(" | ");
      grouped[key] = (grouped[key] || 0) + 1;
    });

    return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }, [sesionesFiltradas, selectedVariables]);

  const COLORS = ["#00A240", "#00C49F", "#FFBB28", "#FF8042", "#0088FE", "#A78BFA"];

  const caninoSel = useMemo(() => caninos.find(c => c.id_canino === selectedCanino), [caninos, selectedCanino]);

  const calcularEdad = (fechaNacimiento: string | null | undefined) => {
    if (!fechaNacimiento) return "—";
    const nac = new Date(fechaNacimiento);
    const hoy = new Date();
    const diff = hoy.getTime() - nac.getTime();
    const años = Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
    return años > 0 ? `${años} año${años > 1 ? "s" : ""}` : "Menos de 1 año";
  };

  const toggleVariable = (v: string) =>
    setSelectedVariables(prev =>
      prev.includes(v) ? prev.filter(x => x !== v) : [...prev, v]
    );

  const handleMultiSelect = (setter: React.Dispatch<React.SetStateAction<number[]>>) =>
    (e: React.ChangeEvent<HTMLSelectElement>) =>
      setter(Array.from(e.target.selectedOptions, opt => Number(opt.value)));

  const renderSidebarSkeleton = () => (
    <div className="p-4 space-y-4">
      {[...Array(5)].map((_, i) => (
        <div key={i} className="flex items-center p-3">
          <div className="w-14 h-14 bg-gray-200 rounded animate-pulse" />
          <div className="ml-3 flex-1 space-y-2">
            <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse" />
            <div className="h-3 bg-gray-200 rounded w-1/2 animate-pulse" />
          </div>
        </div>
      ))}
    </div>
  );

  if (loadingInitial)
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="h-12 w-12 rounded-full border-4 border-[#328D56] border-t-transparent animate-spin" />
      </div>
    );

  return (
    <div className="flex min-h-screen bg-gray-50">
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-full bg-white md:w-80 md:static md:translate-x-0 transition-transform duration-200 ${
          selectedCanino !== null ? "translate-x-0" : "-translate-x-full"
        } md:block`}
      >
        <div className="p-4 flex items-center justify-between">
          <h2 className="font-bold text-lg md:text-xl">Caninos</h2>
          <button
            onClick={() => setSelectedCanino(null)}
            className="md:hidden text-gray-500 hover:text-gray-700"
            aria-label="Cerrar"
          >
            ✕
          </button>
        </div>
        <div className="overflow-y-auto max-h-[calc(100vh-5rem)]">
          {caninos.length === 0 ? (
            renderSidebarSkeleton()
          ) : (
            caninos.map((canino) => (
              <div
                key={canino.id_canino}
                onClick={() => setSelectedCanino(canino.id_canino)}
                className={`flex items-center p-3 cursor-pointer border-l-4 ${
                  selectedCanino === canino.id_canino
                    ? "bg-green-50 border-l-[#00A240]"
                    : "hover:bg-gray-50 border-l-transparent"
                }`}
              >
                <div className="w-14 h-14 flex-shrink-0 bg-gray-200 rounded overflow-hidden">
                  {canino.foto_can_base64 ? (
                    <Image
                      src={obtenerFotoUrl(canino.id_canino)}
                      alt={canino.nombre}
                      width={56}
                      height={56}
                      className="object-cover w-full h-full"
                      unoptimized
                      onError={(e) => (e.currentTarget.style.display = 'none')}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-xs text-gray-500">📷</span>
                    </div>
                  )}
                </div>
                <div className="ml-3 min-w-0">
                  <p className="font-medium truncate">{canino.nombre}</p>
                  <p className="text-xs text-gray-500 truncate">
                    {canino.estado?.descripcion ?? "Sin estado"}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </aside>

      {selectedCanino !== null && (
        <div
          className="fixed inset-0 z-30 bg-black/40 md:hidden"
          onClick={() => setSelectedCanino(null)}
        />
      )}

      <main className="flex-1 md:ml-0">
        <header className="sticky top-0 z-20 bg-white border-b px-4 py-3 md:hidden">
          <div className="flex items-center justify-between">
            <h1 className="text-lg font-bold">Dashboard</h1>
            <button
              onClick={() => setSelectedCanino(-1)}
              className="p-2 rounded-md hover:bg-gray-100"
              aria-label="Seleccionar canino"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </header>

        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          {caninoSel && (
            <section className="mb-8 bg-white rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 md:p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-40 h-40 bg-gray-100 rounded-xl overflow-hidden mx-auto md:mx-0">
                      <div className="w-full h-full bg-gray-100">
                        {caninoSel.foto_can_base64 ? (
                          <Image
                            src={obtenerFotoUrl(caninoSel.id_canino)}
                            alt={caninoSel.nombre}
                            width={160}
                            height={160}
                            unoptimized
                            className="object-cover w-full h-full"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              const parent = e.currentTarget.parentElement;
                              if (parent) {
                                const fallback = parent.querySelector('[data-fallback]');
                                if (fallback) (fallback as HTMLElement).style.display = 'flex';
                              }
                            }}
                          />
                        ) : null}
                        <div
                          data-fallback
                          className="w-full h-full flex items-center justify-center"
                          style={{ display: caninoSel.foto_can_base64 ? 'none' : 'flex' }}
                        >
                          <span className="text-gray-400 text-lg">Sin foto</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1">
                    <h2 className="text-2xl font-bold mb-4">{caninoSel.nombre}</h2>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <InfoItem label="Estado" value={caninoSel.estado?.descripcion ?? "—"} />
                      <InfoItem label="Edad" value={calcularEdad(caninoSel.fecha_nac)} />
                      <InfoItem label="Inicio entrenamiento" value={caninoSel.inicio_ent ?? "—"} />
                      <InfoItem label="Entrenador actual" value={
                        caninoSel.entrenador_actual
                          ? `${caninoSel.entrenador_actual.nombres} ${caninoSel.entrenador_actual.apellidos}`
                          : "No asignado"
                      } />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {caninoSel && sesiones.length > 0 && (
            <section className="mb-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
              <StatCard
                title="Sesiones"
                value={sesionesFiltradas.length}
                icon="📊"
                color="bg-green-100 text-green-800"
              />
              <StatCard
                title="Fases únicas"
                value={new Set(sesionesFiltradas.map(s => s.fase?.nombre)).size - (sesionesFiltradas.some(s => !s.fase) ? 1 : 0)}
                icon="📌"
                color="bg-amber-100 text-amber-800"
              />
              <StatCard
                title="Entrenadores"
                value={new Set(sesionesFiltradas.map(s => s.entrenador?.id_entrenador)).size - (sesionesFiltradas.some(s => !s.entrenador) ? 1 : 0)}
                icon="🧑‍🏫"
                color="bg-indigo-100 text-indigo-800"
              />
              <StatCard
                title="Aromas"
                value={new Set(sesionesFiltradas.map(s => s.aroma?.nombre)).size - (sesionesFiltradas.some(s => !s.aroma) ? 1 : 0)}
                icon="🧪"
                color="bg-purple-100 text-purple-800"
              />
            </section>
          )}

          <h1 className="text-2xl font-bold mb-6">
            {caninoSel ? `Dashboard: ${caninoSel.nombre}` : "Selecciona un canino para comenzar"}
          </h1>

          {!caninoSel ? (
            <div className="text-center py-12 text-gray-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              <p>Selecciona un canino del sidebar para ver su progreso.</p>
            </div>
          ) : (
            <>
              {loadingSesiones && (
                <div className="mb-6 flex justify-center">
                  <div className="h-8 w-8 rounded-full border-4 border-[#328D56] border-t-transparent animate-spin" />
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <section className="lg:col-span-2 bg-white rounded-xl shadow-sm p-4 md:p-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
                    <h2 className="text-xl font-semibold">
                      {sesiones.length} sesión{sesiones.length !== 1 ? "es" : ""} registrada{sesiones.length !== 1 ? "s" : ""}
                    </h2>
                    <select
                      value={selectedChart}
                      onChange={(e) => setSelectedChart(e.target.value as any)}
                      className="px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500"
                    >
                      <option value="bar">Barras</option>
                      <option value="pie">Pastel</option>
                      <option value="line">Líneas</option>
                    </select>
                  </div>

                  {sesionesFiltradas.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>No hay sesiones con los filtros actuales.</p>
                    </div>
                  ) : chartData.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <p>No hay datos para graficar con las variables seleccionadas.</p>
                    </div>
                  ) : (
                    <div className="h-[300px] md:h-[360px]">
                      <ResponsiveContainer width="100%" height="100%">
                        {selectedChart === "pie" ? (
                          <PieChart>
                            <Pie data={chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                              {chartData.map((_, i) => <Cell key={`cell-${i}`} fill={COLORS[i % COLORS.length]} />)}
                            </Pie>
                            <Tooltip />
                            <Legend />
                          </PieChart>
                        ) : selectedChart === "line" ? (
                          <LineChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis
                              dataKey="name"
                              angle={-45}
                              textAnchor="end"
                              height={70}
                              tick={{ fontSize: 11 }}
                              interval={0}
                            />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="value" stroke="#00A240" strokeWidth={2} dot={{ r: 4 }} />
                          </LineChart>
                        ) : (
                          <BarChart data={chartData}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis
                              dataKey="name"
                              angle={-45}
                              textAnchor="end"
                              height={70}
                              tick={{ fontSize: 11 }}
                              interval={0}
                            />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="value" fill="#00A240" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        )}
                      </ResponsiveContainer>
                    </div>
                  )}
                </section>

                <section className="bg-white rounded-xl shadow-sm p-4 md:p-6 h-fit">
                  <h3 className="text-lg font-semibold mb-4">Filtros</h3>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Variables</label>
                      <div className="grid grid-cols-2 gap-2">
                        {["entrenador", "fase", "aroma", "resultado", "puntuacion", "duracion", "mes"].map((v) => (
                          <label key={v} className="flex items-center text-sm">
                            <input
                              type="checkbox"
                              checked={selectedVariables.includes(v)}
                              onChange={() => toggleVariable(v)}
                              className="rounded text-green-600 focus:ring-green-500"
                            />
                            <span className="ml-2 capitalize">{v}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Entrenadores</label>
                      <select
                        multiple
                        size={3}
                        onChange={handleMultiSelect(setSelectedEntrenadores)}
                        className="w-full text-sm border rounded-lg p-2 focus:ring-2 focus:ring-green-500"
                      >
                        {entrenadores.map((e) => (
                          <option key={e.id_entrenador} value={e.id_entrenador}>
                            {e.nombres} {e.apellidos}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Fases</label>
                      <select
                        multiple
                        size={3}
                        onChange={handleMultiSelect(setSelectedFases)}
                        className="w-full text-sm border rounded-lg p-2 focus:ring-2 focus:ring-green-500"
                      >
                        {fases.map((f) => (
                          <option key={f.id_fase} value={f.id_fase}>
                            {f.nombre}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Aromas</label>
                      <select
                        multiple
                        size={3}
                        onChange={handleMultiSelect(setSelectedAromas)}
                        className="w-full text-sm border rounded-lg p-2 focus:ring-2 focus:ring-green-500"
                      >
                        {aromas.map((a) => (
                          <option key={a.id_aroma} value={a.id_aroma}>
                            {a.nombre}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </section>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}

const InfoItem = ({ label, value }: { label: string; value: string }) => (
  <div>
    <dt className="font-medium text-gray-600">{label}:</dt>
    <dd className="mt-0.5 text-gray-900">{value}</dd>
  </div>
);

const StatCard = ({ title, value, icon, color }: { title: string; value: number; icon: string; color: string }) => (
  <div className="bg-white rounded-xl shadow-sm p-4 text-center">
    <div className={`inline-flex w-10 h-10 items-center justify-center rounded-lg ${color} mb-3 mx-auto`}>
      <span>{icon}</span>
    </div>
    <p className="text-2xl font-bold">{value}</p>
    <p className="text-sm text-gray-600 mt-1">{title}</p>
  </div>
);

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}