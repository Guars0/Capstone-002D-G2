"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import axiosInstance from "@/utils/AxiosInstance";
import Image from "next/image";
import { ProtectedRoute } from "@/app/components/ProtectedRoute";

interface Estado {
  id_estado: number;
  descripcion: string;
}

interface Centro {
  id_centro: number;
  nombre_centro: string;
}

interface Canino {
  id_canino: number;
  nombre: string;
  raza?: string | null;
  foto_can_base64?: string | null;
  fecha_nac: string | null;
  inicio_ent: string | null;
  fin_ent: string | null;
  estado: Estado | null;
  centro: Centro | null;
}

interface Sesion {
  id_sesion: number;
  fecha_ini: string | null;
  fecha_fin: string | null;
  observaciones: string | null;
  entrenador: {
    id_entrenador: number;
    nombre_completo: string;
  };
  fase: { nombre: string } | null;
  aroma: { nombre: string } | null;
  video_url: string | null;
}

const sesionesCache = new Map<string, Sesion[]>();

function FichaCanContent() {
  const params = useParams();
  const id = params?.id;
  const router = useRouter();
  const [canino, setCanino] = useState<Canino | null>(null);
  const [sesiones, setSesiones] = useState<Sesion[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [videoStates, setVideoStates] = useState<Record<number, boolean>>({});

  const formatDateTime = (iso: string | null) => {
    if (!iso) return "—";
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString("es-CL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const calcularEdad = (fecha: string | null) => {
    if (!fecha) return "—";
    const nacimiento = new Date(fecha);
    const hoy = new Date();
    let años = hoy.getFullYear() - nacimiento.getFullYear();
    let meses = hoy.getMonth() - nacimiento.getMonth();
    if (meses < 0) {
      años--;
      meses += 12;
    }
    return años > 0
      ? `${años} año${años > 1 ? "s" : ""}`
      : `${meses} mes${meses > 1 ? "es" : ""}`;
  };

  useEffect(() => {
    if (!id) {
      setError("ID de canino no proporcionado");
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const cached = sesionesCache.get(id.toString());
        if (cached) {
          setSesiones(cached);
        } else {
          const resSesiones = await axiosInstance.get<Sesion[]>(`sesiones/por_canino/?canino_id=${id}`);
          setSesiones(resSesiones.data);
          sesionesCache.set(id.toString(), resSesiones.data);
        }

        const resCanino = await axiosInstance.get<Canino>(`caninos/${id}/`);
        setCanino(resCanino.data);
      } catch (err) {
        console.error("Error al cargar datos:", err);
        setError("Error al cargar la información del canino. Por favor, intente nuevamente.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  const toggleVideo = (id_sesion: number) => {
    setVideoStates(prev => ({
      ...prev,
      [id_sesion]: !prev[id_sesion]
    }));
  };

  if (loading) return (
    <main className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-center py-12">
          <div className="h-10 w-10 rounded-full border-4 border-[#00A240] border-t-transparent animate-spin"></div>
        </div>
      </div>
    </main>
  );

  if (error) return (
    <main className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border p-6">
          <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-4">
            {error}
          </div>
          <button
            onClick={() => router.push("/listacan")}
            className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
          >
            Volver a la lista
          </button>
        </div>
      </div>
    </main>
  );

  if (!canino) return (
    <main className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border p-6 text-center">
          <p className="text-gray-600">No se encontró el canino solicitado.</p>
          <button
            onClick={() => router.push("/listacan")}
            className="mt-4 text-[#00A240] font-medium hover:underline"
          >
            ← Volver a la lista de caninos
          </button>
        </div>
      </div>
    </main>
  );

  return (
    <main className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* ENCABEZADO */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
              Ficha de Canino
            </h1>
            <button
              onClick={() => router.push("/listacan")}
              className="px-4 py-2 bg-[#328D56] text-white font-medium rounded-lg hover:bg-[#2a7a4a] transition-colors"
            >
              ← Volver a la lista
            </button>
          </div>
        </div>

        {/* CARD PRINCIPAL */}
        <section className="bg-white rounded-xl shadow-sm mb-8 overflow-hidden">
          <div className="p-4 sm:p-6">
            <div className="flex flex-col lg:flex-row gap-6">
              {/* IMAGEN */}
              <div className="flex-shrink-0 w-full lg:w-64">
                <div className="rounded-xl overflow-hidden bg-gray-100 aspect-square flex items-center justify-center">
                  {canino.foto_can_base64 ? (
                    <Image
                      src={`data:image/jpeg;base64,${canino.foto_can_base64}`}
                      alt={canino.nombre}
                      width={256}
                      height={256}
                      className="w-full h-full object-cover"
                      unoptimized
                    />
                  ) : (
                    <div className="text-gray-500 text-center p-4">
                      <span className="text-5xl">🐾</span>
                      <p className="mt-2">Sin foto</p>
                    </div>
                  )}
                </div>
              </div>

              {/* INFORMACIÓN */}
              <div className="flex-1">
                <div className="mb-4">
                  <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-1">
                    {canino.nombre}
                  </h2>
                  {canino.estado && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                      {canino.estado.descripcion}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium text-gray-600 mb-1">Inicio entrenamiento</h3>
                    <p className="text-gray-800">
                      {canino.inicio_ent ? new Date(canino.inicio_ent).toLocaleDateString('es-CL') : "No definido"}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-600 mb-1">Fin estimado</h3>
                    <p className="text-gray-800">
                      {canino.fin_ent ? new Date(canino.fin_ent).toLocaleDateString('es-CL') : "No definido"}
                    </p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-600 mb-1">Edad</h3>
                    <p className="text-gray-800">{calcularEdad(canino.fecha_nac)}</p>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-600 mb-1">Centro</h3>
                    <p className="text-gray-800">{canino.centro?.nombre_centro || "No asignado"}</p>
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SESIONES */}
        <section>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Sesiones de Entrenamiento</h2>
            <span className="text-sm text-gray-500">
              {sesiones.length} {sesiones.length === 1 ? "sesión" : "sesiones"}
            </span>
          </div>

          {sesiones.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border p-6 text-center">
              <p className="text-gray-600">No hay sesiones registradas para este canino aún.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sesiones.map((s) => (
                <article key={s.id_sesion} className="bg-white rounded-lg shadow-sm overflow-hidden">
                  <div className="p-4">
                    <div className="flex flex-wrap items-center gap-2 mb-4">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        📅 {formatDateTime(s.fecha_ini).split(',')[0]}
                      </span>
                      {s.fase && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                          {s.fase.nombre}
                        </span>
                      )}
                      {s.aroma && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                          {s.aroma.nombre}
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm mb-4">
                      <dt className="font-medium text-gray-600">Entrenador:</dt>
                      <dd className="text-gray-800">{s.entrenador.nombre_completo}</dd>
                      <dt className="font-medium text-gray-600">Duración:</dt>
                      <dd className="text-gray-800">
                        {s.fecha_ini && s.fecha_fin 
                          ? `${Math.round((new Date(s.fecha_fin).getTime() - new Date(s.fecha_ini).getTime()) / 60000)} min`
                          : "—"}
                      </dd>
                    </div>

                    {s.observaciones && (
                      <div className="mt-3 pt-3 border-t border-gray-100">
                        <p className="text-sm text-gray-700">
                          <span className="font-medium text-gray-600">Observaciones:</span> {s.observaciones}
                        </p>
                      </div>
                    )}

                    {s.video_url && (
                      <div className="mt-4">
                        {videoStates[s.id_sesion] ? (
                          <div className="relative">
                            <video
                              key={s.id_sesion}
                              controls
                              className="w-full rounded border"
                              preload="none"
                              onPlay={() => {
                                Object.keys(videoStates).forEach(id => {
                                  if (parseInt(id) !== s.id_sesion && videoStates[parseInt(id)]) {
                                    const otherVideo = document.querySelector(`video[data-session-id="${id}"]`) as HTMLVideoElement;
                                    if (otherVideo) otherVideo.pause();
                                  }
                                });
                              }}
                              data-session-id={s.id_sesion}
                            >
                              <source src={s.video_url} type="video/mp4" />
                              Tu navegador no soporta el elemento de video.
                            </video>
                            <button
                              onClick={() => toggleVideo(s.id_sesion)}
                              className="absolute top-2 right-2 bg-black bg-opacity-50 text-white rounded px-2 py-1 text-sm hover:bg-opacity-70"
                            >
                              Ocultar
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => toggleVideo(s.id_sesion)}
                            className="w-full flex items-center justify-center gap-3 py-3 bg-gray-50 hover:bg-gray-100 rounded-lg border border-dashed border-gray-300 transition-colors"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="h-5 w-5 text-[#00A240]"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                              />
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                              />
                            </svg>
                            <span className="font-medium text-gray-700">Ver video de la sesión</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

export default function FichaCanPage() {
  return (
    <ProtectedRoute>
      <FichaCanContent />
    </ProtectedRoute>
  );
}