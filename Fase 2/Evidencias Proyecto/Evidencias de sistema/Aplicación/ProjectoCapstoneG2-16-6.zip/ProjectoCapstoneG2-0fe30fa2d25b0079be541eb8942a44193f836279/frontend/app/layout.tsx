import "./globals.css";
import { Inter } from "next/font/google";
import Navbar from "@/app/components/navbar";
import Footer from "@/app/components/footer";
import Contacto from "@/app/components/contacto";
import MainContent from "@/app/components/MainContent";
import type { Viewport } from "next";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "SAG Caninos",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head >
        <meta name="format-detection" content="telephone=no, date=no, email=no, address=no"/>
      </head>
      <body className={`${inter.className} flex flex-col min-h-screen`}>
        <Navbar /> 
        <Contacto />
        <MainContent>{children}</MainContent>
        <Footer />
      </body>
    </html>
  );
}