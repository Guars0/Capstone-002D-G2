"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  AreaChart,
  Area,
} from "recharts";

type Canino = {
  id_canino: number;
  nombre: string;
  foto_can: string | null;
  estado: { descripcion: string } | null;
  fecha_nac?: string | null;
  inicio_ent?: string | null;
  fin_ent?: string | null;
};

type Sesion = {
  id_sesion: string;
  canino: { nombre: string } | null;
  entrenador: { nombres: string; apellidos: string } | null;
  fase: { nombre: string } | null;
  fecha_hora_ini: string;
  fecha_hora_fin: string;
  aroma?: { nombre: string } | null;
  exito?: boolean;
  duracion?: number; // minutos
};

const COLORS = ["#00A240", "#00C49F", "#FFBB28", "#FF8042", "#0088FE", "#A28FD0", "#FF6B6B"];

export default function DashboardPowerBI() {
  const [caninos, setCaninos] = useState<Canino[]>([]);
  const [sesiones, setSesiones] = useState<Sesion[]>([]);
  const [selectedCanino, setSelectedCanino] = useState<number | null>(null);

  // --- Variables para gráficos dinámicos
  const [selectedVariables, setSelectedVariables] = useState<string[]>(["canino"]);
  const [selectedChart, setSelectedChart] = useState("bar");

  // --- Datos falsos
  useEffect(() => {
    const caninosFake: Canino[] = [
      { id_canino: 1, nombre: "Rex", foto_can: null, estado: { descripcion: "Activo" }, fecha_nac: "2020-01-15", inicio_ent: "2023-01-01", fin_ent: "2023-06-01" },
      { id_canino: 2, nombre: "Luna", foto_can: null, estado: { descripcion: "En entrenamiento" }, fecha_nac: "2021-05-20", inicio_ent: "2023-03-01", fin_ent: "2023-09-01" },
      { id_canino: 3, nombre: "Max", foto_can: null, estado: { descripcion: "Activo" }, fecha_nac: "2019-08-10", inicio_ent: "2023-02-01", fin_ent: "2023-07-01" },
      { id_canino: 4, nombre: "Bella", foto_can: null, estado: { descripcion: "Activo" }, fecha_nac: "2022-02-25", inicio_ent: "2023-04-01", fin_ent: "2023-10-01" },
    ];

    const fases = ["Obediencia", "Agility", "Protección", "Rastreo"];
    const aromas = ["Lavanda", "Menta", "Cítricos", "Canela"];
    const entrenadores = [
      { nombres: "Juan", apellidos: "Pérez" },
      { nombres: "María", apellidos: "González" },
      { nombres: "Carlos", apellidos: "Soto" },
    ];

    const sesionesFake: Sesion[] = [];
    let id = 1;
    caninosFake.forEach((can) => {
      for (let i = 0; i < 8; i++) {
        const duracion = Math.floor(Math.random() * 90) + 30; // 30-120 min
        const fecha_ini = new Date(2023, Math.floor(Math.random() * 6), Math.floor(Math.random() * 28) + 1, 9 + Math.floor(Math.random() * 5), 0);
        const fecha_fin = new Date(fecha_ini.getTime() + duracion * 60000);
        sesionesFake.push({
          id_sesion: `${id++}`,
          canino: { nombre: can.nombre },
          entrenador: entrenadores[Math.floor(Math.random() * entrenadores.length)],
          fase: { nombre: fases[Math.floor(Math.random() * fases.length)] },
          aroma: { nombre: aromas[Math.floor(Math.random() * aromas.length)] },
          fecha_hora_ini: fecha_ini.toISOString(),
          fecha_hora_fin: fecha_fin.toISOString(),
          exito: Math.random() > 0.3,
          duracion,
        });
      }
    });

    setCaninos(caninosFake);
    setSesiones(sesionesFake);
  }, []);

  // --- Funciones auxiliares
  const calcularEdad = (fechaNacimiento: string | null | undefined) => {
    if (!fechaNacimiento) return "-";
    const nacimiento = new Date(fechaNacimiento);
    const hoy = new Date();
    let años = hoy.getFullYear() - nacimiento.getFullYear();
    let meses = hoy.getMonth() - nacimiento.getMonth();
    const dias = hoy.getDate() - nacimiento.getDate();
    if (dias < 0) meses -= 1;
    if (meses < 0) {
      años -= 1;
      meses += 12;
    }
    if (años <= 0 && meses > 0) return `${meses} mes${meses > 1 ? "es" : ""}`;
    if (años <= 0) return "menos de 1 mes";
    if (meses === 0) return `${años} año${años > 1 ? "s" : ""}`;
    return `${años} año${años > 1 ? "s" : ""} ${meses} mes${meses > 1 ? "es" : ""}`;
  };

  const sesionesFiltradas = selectedCanino
    ? sesiones.filter((s) => s.canino?.nombre === caninos.find((c) => c.id_canino === selectedCanino)?.nombre)
    : sesiones;

  // --- Generar datos según variables seleccionadas (PowerBI style)
  const generarDatos = (variables: string[]) => {
    const acc: Record<string, number> = {};
    sesionesFiltradas.forEach((s) => {
      const key = variables
        .map((v) => {
          switch (v) {
            case "canino": return s.canino?.nombre ?? "Desconocido";
            case "fase": return s.fase?.nombre ?? "Sin fase";
            case "aroma": return s.aroma?.nombre ?? "Sin aroma";
            case "entrenador": return s.entrenador ? `${s.entrenador.nombres} ${s.entrenador.apellidos}` : "-";
            case "exito": return s.exito ? "Éxito" : "Fracaso";
            case "duracion":
              if (!s.duracion) return "-";
              return s.duracion <= 45 ? "≤45 min" : s.duracion <= 90 ? "46-90 min" : ">90 min";
            case "edad":
              const can = caninos.find((c) => c.nombre === s.canino?.nombre);
              return can ? calcularEdad(can.fecha_nac) : "-";
            default: return "Otro";
          }
        })
        .join(" | ");
      acc[key] = (acc[key] || 0) + 1;
    });
    return Object.entries(acc).map(([name, value]) => ({ name, value }));
  };

  const data = generarDatos(selectedVariables);
  const caninoSel = caninos.find((c) => c.id_canino === selectedCanino);

  const renderChart = () => {
    switch (selectedChart) {
      case "bar":
        return (
          <BarChart width={600} height={300} data={data}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="value" fill="#00A240" />
          </BarChart>
        );
      case "pie":
        return (
          <PieChart width={600} height={300}>
            <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label>
              {data.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
            </Pie>
            <Tooltip />
          </PieChart>
        );
      case "line":
        return (
          <LineChart width={600} height={300} data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="value" stroke="#00A240" />
          </LineChart>
        );
      case "area":
        return (
          <AreaChart width={600} height={300} data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="value" stroke="#00A240" fill="#00A240" />
          </AreaChart>
        );
      default:
        return null;
    }
  };

  const variablesDisponibles = [
    { value: "canino", label: "Canino" },
    { value: "fase", label: "Fase" },
    { value: "aroma", label: "Aroma" },
    { value: "entrenador", label: "Entrenador" },
    { value: "exito", label: "Éxito/Fracaso" },
    { value: "duracion", label: "Duración de Sesión" },
    { value: "edad", label: "Edad Canino" },
  ];

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Panel lateral */}
      <aside className="w-102 bg-white shadow-md p-4 border-r border-[#F6F6F6]">
        <h2 className="font-roboto font-bold text-[36px] text-center mb-2">Caninos</h2>
        <div className="overflow-y-auto max-h-[80vh]">
          {caninos.map((can) => (
            <div
              key={can.id_canino}
              onClick={() => setSelectedCanino(can.id_canino)}
              className={`flex items-center p-3 cursor-pointer transition-colors ${selectedCanino === can.id_canino ? "bg-green-100" : "hover:bg-gray-100"}`}
            >
              <div className="w-[93px] h-[90px] flex items-center justify-center overflow-hidden bg-gray-200 rounded-lg">
                {can.foto_can ? <Image src={can.foto_can} alt={can.nombre} width={93} height={90} className="w-full h-full object-cover object-center" unoptimized /> : <span className="text-gray-400 text-sm">Sin foto</span>}
              </div>
              <div className="ml-4">
                <p className="font-roboto text-[24px] font-normal">{can.nombre}</p>
                <p className="font-roboto text-[16px] font-light text-gray-600">{can.estado?.descripcion ?? "Sin estado"}</p>
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* Panel principal */}
      <main className="flex-1 p-6 space-y-10 bg-white ml-3">
        {caninoSel && (
          <div className="flex gap-6 mb-6">
            <div className="w-[222px] h-[215px] flex items-center justify-center overflow-hidden bg-gray-100 rounded-lg">
              {caninoSel.foto_can ? <Image src={caninoSel.foto_can} alt={caninoSel.nombre} width={222} height={215} className="w-full h-full object-cover object-center" unoptimized /> : <span className="text-gray-400 text-sm">Sin foto</span>}
            </div>
            <div className="flex-1">
              <h2 className="font-roboto font-bold text-[36px] mb-3">Información del Canino</h2>
              <div className="flex gap-6">
                <div className="flex-1 min-h-[120px] text-[16px] font-roboto font-light cursor-text">Vista de prueba de descripción.</div>
                <div className="flex-1 text-[18px] font-light space-y-2">
                  <div className="flex justify-between"><span>Inicio:</span><span>{caninoSel.inicio_ent ?? "-"}</span></div>
                  <div className="flex justify-between"><span>Fin:</span><span>{caninoSel.fin_ent ?? "-"}</span></div>
                  <div className="flex justify-between"><span>Edad:</span><span>{calcularEdad(caninoSel.fecha_nac)}</span></div>
                </div>
              </div>
            </div>
          </div>
        )}

        <h1 className="text-2xl font-bold mb-4">Dashboard Interactivo {selectedCanino ? `— ${caninos.find(c => c.id_canino === selectedCanino)?.nombre}` : ""}</h1>

        {/* Selectores tipo PowerBI */}
        <div className="flex gap-4 mb-4">
          <select multiple className="border p-2 rounded h-32" value={selectedVariables} onChange={(e) => setSelectedVariables(Array.from(e.target.selectedOptions, opt => opt.value))}>
            {variablesDisponibles.map(v => <option key={v.value} value={v.value}>{v.label}</option>)}
          </select>
          <select className="border p-2 rounded" value={selectedChart} onChange={(e) => setSelectedChart(e.target.value)}>
            <option value="bar">Barras</option>
            <option value="pie">Pastel</option>
            <option value="line">Líneas</option>
            <option value="area">Área</option>
          </select>
        </div>

        <div className="bg-white p-4 rounded" style={{ boxShadow: "0 -2px 6px #F6F6F6, 0 4px 6px #F6F6F6" }}>
          {renderChart()}
        </div>

        <div className="bg-white p-4 rounded" style={{ boxShadow: "0 -2px 6px #F6F6F6, 0 4px 6px #F6F6F6" }}>
          <h2 className="font-semibold mb-2">Tabla de Sesiones</h2>
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th>Canino</th>
                <th>Entrenador</th>
                <th>Fase</th>
                <th>Aroma</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Éxito</th>
                <th>Duración</th>
              </tr>
            </thead>
            <tbody>
              {sesionesFiltradas.map(s => (
                <tr key={s.id_sesion} className="border-t">
                  <td>{s.canino?.nombre ?? "-"}</td>
                  <td>{s.entrenador ? `${s.entrenador.nombres} ${s.entrenador.apellidos}` : "-"}</td>
                  <td>{s.fase?.nombre ?? "-"}</td>
                  <td>{s.aroma?.nombre ?? "-"}</td>
                  <td>{s.fecha_hora_ini}</td>
                  <td>{s.fecha_hora_fin}</td>
                  <td>{s.exito ? "Sí" : "No"}</td>
                  <td>{s.duracion ?? "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
