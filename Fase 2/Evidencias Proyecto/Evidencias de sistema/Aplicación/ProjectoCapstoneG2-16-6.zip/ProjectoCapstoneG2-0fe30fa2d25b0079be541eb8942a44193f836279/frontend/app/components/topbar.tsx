import Image from "next/image";

export default function TopBar() {
  return (
    <div className="fixed top-0 left-0 w-full bg-white border-b border-gray-300 z-50 h-16 flex items-center px-4">
      <Image
        src="/logo_min_agricultura.svg"
        alt="Logo Gobierno de Chile - Ministerio de Agricultura"
        width={160}
        height={50}
        priority
        className="h-auto w-auto"
      />
    </div>
  );
}