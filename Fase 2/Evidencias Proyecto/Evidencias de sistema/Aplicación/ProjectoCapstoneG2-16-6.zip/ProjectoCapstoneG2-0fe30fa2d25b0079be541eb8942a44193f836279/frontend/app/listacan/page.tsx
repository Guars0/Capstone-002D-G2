"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import Link from "next/link";
import axiosInstance from "@/utils/AxiosInstance";
import { ProtectedRoute } from "@/app/components/ProtectedRoute";
import { useInView } from 'react-intersection-observer';

interface Estado {
  id_estado: number;
  descripcion: string;
}

interface Centro {
  id_centro: number;
  nombre_centro: string;
}

interface Canino {
  id_canino: number;
  nombre: string;
  estado: Estado | null;
  centro: Centro | null;
  foto_can_base64?: string | null;
}

function ListaCanContent() {
  const [caninos, setCaninos] = useState<Canino[]>([]);
  const [filtered, setFiltered] = useState<Canino[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("todos");
  const [centroFiltro, setCentroFiltro] = useState("todos");
  const [currentPage, setCurrentPage] = useState(1);
  const { ref: listRef, inView: listInView } = useInView({ triggerOnce: true });

  const pageSize = 6;
  const totalPages = Math.ceil(filtered.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginaActual = filtered.slice(startIndex, endIndex);

  const cargarCaninos = useCallback(async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    try {
      setLoading(true);
      const res = await axiosInstance.get("/caninos/", { signal: controller.signal });
      const data = Array.isArray(res.data) ? res.data : res.data.results || [];
      setCaninos(data);
      setFiltered(data);
    } catch (err: any) {
      if (err.name === 'CanceledError' || err.code === 'ERR_CANCELED') return;
      console.error("Error cargando caninos:", err);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    cargarCaninos();
  }, [cargarCaninos]);

  const estadosUnicos = useMemo(() => {
    const set = new Set<string>();
    caninos.forEach(c => {
      if (c.estado?.descripcion) set.add(c.estado.descripcion);
    });
    return Array.from(set);
  }, [caninos]);

  const centrosUnicos = useMemo(() => {
    const set = new Set<string>();
    caninos.forEach(c => {
      if (c.centro?.nombre_centro) set.add(c.centro.nombre_centro);
    });
    return Array.from(set);
  }, [caninos]);

  useEffect(() => {
    let result = [...caninos];

    if (search.trim() !== "")
      result = result.filter(c =>
        c.nombre.toLowerCase().includes(search.toLowerCase())
      );

    if (estadoFiltro !== "todos")
      result = result.filter(c => c.estado?.descripcion === estadoFiltro);

    if (centroFiltro !== "todos")
      result = result.filter(c => c.centro?.nombre_centro === centroFiltro);

    setFiltered(result);
    setCurrentPage(1); // Resetear a página 1 al cambiar filtros
  }, [search, estadoFiltro, centroFiltro, caninos]);

  const getFotoUrl = (caninoId: number) =>
    `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/caninos/${caninoId}/foto/`;

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (loading)
    return <p className="text-center mt-20 text-gray-500">Cargando...</p>;

  return (
    <div className="max-w-7xl mx-auto mt-10 p-6">
      <h1 className="text-4xl font-bold mb-6 text-center font-roboto">
        Lista de Caninos
      </h1>

      <div className="flex flex-col md:flex-row flex-wrap justify-between items-center mb-6 gap-4">
        <input
          type="text"
          placeholder="Buscar por nombre..."
          className="border border-gray-300 px-4 py-2 rounded-lg w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-green-500"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          className="border border-gray-300 px-4 py-2 rounded-lg w-full md:w-auto focus:outline-none focus:ring-2 focus:ring-green-500"
          value={estadoFiltro}
          onChange={(e) => setEstadoFiltro(e.target.value)}
        >
          <option value="todos">Todos los estados</option>
          {estadosUnicos.map((estado, idx) => (
            <option key={idx} value={estado}>
              {estado}
            </option>
          ))}
        </select>

        <select
          className="border border-gray-300 px-4 py-2 rounded-lg w-full md:w-auto focus:outline-none focus:ring-2 focus:ring-green-500"
          value={centroFiltro}
          onChange={(e) => setCentroFiltro(e.target.value)}
        >
          <option value="todos">Todos los centros</option>
          {centrosUnicos.map((centro, idx) => (
            <option key={idx} value={centro}>
              {centro}
            </option>
          ))}
        </select>
      </div>

      <div ref={listRef}>
        {!listInView ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 bg-[#BAD7BB] rounded-2xl">
                <div className="flex flex-col sm:flex-row items-center gap-6 w-full">
                  <div className="w-24 h-24 bg-gray-200 rounded-lg animate-pulse"></div>
                  <div className="text-center sm:text-left space-y-2">
                    <div className="h-5 bg-gray-200 rounded w-24 animate-pulse"></div>
                    <div className="h-4 bg-gray-200 rounded w-32 animate-pulse"></div>
                    <div className="h-4 bg-gray-200 rounded w-32 animate-pulse"></div>
                  </div>
                </div>
                <div className="w-full sm:w-auto h-10 bg-gray-200 rounded animate-pulse"></div>
              </div>
            ))}
          </div>
        ) : paginaActual.length === 0 ? (
          <p className="text-center mt-20 text-gray-500 text-lg font-semibold">
            No se encontraron resultados.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {paginaActual.map((canino) => (
              <div
                key={canino.id_canino}
                className="flex flex-col sm:flex-row items-center justify-between gap-6 p-6 bg-[#BAD7BB] rounded-2xl shadow-md hover:shadow-lg transition-all"
              >
                <div className="flex flex-col sm:flex-row items-center gap-6 w-full">
                  <div className="w-24 h-24 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center">
                    {canino.id_canino && canino.foto_can_base64 ? (
                      <img
                        src={getFotoUrl(canino.id_canino)}
                        alt={canino.nombre}
                        width={96}
                        height={96}
                        className="object-cover w-full h-full"
                        loading="lazy"
                        onError={(e) => (e.currentTarget.style.display = 'none')}
                      />
                    ) : (
                      <span className="text-gray-600 text-sm">Sin imagen</span>
                    )}
                  </div>

                  <div className="text-center sm:text-left">
                    <p className="font-semibold text-gray-900 text-lg">
                      {canino.nombre}
                    </p>
                    <p className="text-sm text-gray-800">
                      Estado: {canino.estado?.descripcion ?? "Sin estado"}
                    </p>
                    <p className="text-sm text-gray-800">
                      Centro: {canino.centro?.nombre_centro ?? "No asignado"}
                    </p>
                  </div>
                </div>

                <Link
                  href={`/fichacan/${canino.id_canino}`}
                  className="bg-[#328D56] text-white font-semibold px-4 py-2 rounded-lg hover:bg-green-700 transition-colors w-full sm:w-auto text-center"
                >
                  Ver más
                </Link>
              </div>
            ))}
          </div>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-8">
          <div className="text-sm text-gray-600 mb-4 text-center">
            Mostrando {startIndex + 1}–{Math.min(endIndex, filtered.length)} de {filtered.length} canino{filtered.length !== 1 ? 's' : ''}
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className={`px-4 py-2 rounded-lg font-medium ${
                currentPage === 1
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-white text-gray-800 hover:bg-gray-100 border border-gray-300'
              }`}
            >
              « Anterior
            </button>

            {[...Array(totalPages)].map((_, i) => {
              const page = i + 1;
              // Mostrar solo las primeras 2, últimas 2 y las alrededor de la actual
              if (
                page === 1 ||
                page === totalPages ||
                (page >= currentPage - 1 && page <= currentPage + 1)
              ) {
                return (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`px-4 py-2 rounded-lg font-medium min-w-[40px] ${
                      currentPage === page
                        ? 'bg-[#328D56] text-white'
                        : 'bg-white text-gray-800 hover:bg-gray-100 border border-gray-300'
                    }`}
                  >
                    {page}
                  </button>
                );
              }
              // Separador entre rangos
              if (page === currentPage - 2 && currentPage > 3) {
                return <span key="left-ellipsis" className="px-2 py-2">…</span>;
              }
              if (page === currentPage + 2 && currentPage < totalPages - 2) {
                return <span key="right-ellipsis" className="px-2 py-2">…</span>;
              }
              return null;
            })}

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className={`px-4 py-2 rounded-lg font-medium ${
                currentPage === totalPages
                  ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  : 'bg-white text-gray-800 hover:bg-gray-100 border border-gray-300'
              }`}
            >
              Siguiente »
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ListaCanPage() {
  return (
    <ProtectedRoute>
      <ListaCanContent />
    </ProtectedRoute>
  );
}