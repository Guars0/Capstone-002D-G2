// app/components/MainContent.tsx
"use client";

import { usePathname } from "next/navigation";
import { useAuthStore } from "@/app/hooks/useAuthStore";

export default function MainContent({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  const pathname = usePathname();

  const showTopBar = isAuthenticated && pathname !== "/login";

  const marginTop = showTopBar ? "mt-[144px]" : "mt-20"; // 20 = 5rem = 80px

  return <main className={`flex-1 ${marginTop}`}>{children}</main>;
}