"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { useAuthStore, logoutAuth } from "@/app/hooks/useAuthStore";
import { Toast } from "@/app/components/toast";
import Image from "next/image";

export default function Navbar() {
  const { isAuthenticated, username, isSuperUser } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();

  const [showNavbar, setShowNavbar] = useState(true);
  const [lastScroll, setLastScroll] = useState(0);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showLogoutToast, setShowLogoutToast] = useState(false);

  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;
      if (window.innerWidth < 768) {
        if (currentScroll > lastScroll && currentScroll > 50) {
          setShowNavbar(false);
        } else {
          setShowNavbar(true);
        }
      } else {
        setShowNavbar(true);
      }
      setLastScroll(currentScroll);
    };

    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [lastScroll]);

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    localStorage.removeItem("username");
    localStorage.removeItem("isSuperUser");
    logoutAuth();
    setShowLogoutToast(true);
    setTimeout(() => router.push("/login"), 1000);
  };

  const showTopBar = isAuthenticated && pathname !== "/login";

  return (
    <>
      {/* TopBar solo si corresponde */}
      {showTopBar && (
        <div className="fixed top-0 left-0 w-full bg-white border-b border-gray-300 z-50 h-16 flex items-center px-4">
          <Image
            src="/logo_min_agricultura.svg"
            alt="Logo Ministerio de Agricultura"
            width={160}
            height={50}
            priority
          />
        </div>
      )}

      {showLogoutToast && <Toast message="Sesión cerrada correctamente" />}

      {/* Navbar principal */}
      <nav
        className={`fixed ${
          showTopBar ? "top-16" : "top-0"
        } left-0 w-full z-50 bg-[#00A240] shadow-md h-20 px-4 md:px-6 transition-transform duration-300 ${
          showNavbar ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="h-full flex items-center justify-between">
          {/* Botón menú móvil (solo móvil) */}
          {isAuthenticated && (
            <button
              className="md:hidden text-white text-2xl mr-2"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="Menú"
            >
              ☰
            </button>
          )}

          {/* LOGO - centrado visual en móvil, izquierda en desktop */}
          <div className="absolute left-1/2 -translate-x-1/2 md:static md:left-auto md:translate-x-0 flex items-center space-x-1">
            <Link href="/" className="flex items-center space-x-1">
              <h1 className="font-inter text-white font-bold text-2xl md:text-3xl lg:text-4xl">
                SAG
              </h1>
              <span className="text-white font-normal text-xl md:text-2xl lg:text-3xl">|</span>
              <h2 className="font-inter text-white font-medium text-2xl md:text-3xl lg:text-4xl">
                Caninos
              </h2>
            </Link>
          </div>

          {/* Espacio flexible para empujar links/dropdown a la derecha */}
          <div className="flex-1 md:flex-none"></div>

          {/* Links y dropdown (derecha) */}
          <div className="flex items-center space-x-4 md:space-x-6">
            {isAuthenticated && (
              <>
                {/* Menú escritorio */}
                <div className="hidden md:flex items-center space-x-4 md:space-x-6">
                  <Link href="/listacan" className="text-white text-lg hover:text-[#d1f0d4] transition-colors">
                    Caninos
                  </Link>
                  <Link href="/dashboard" className="text-white text-lg hover:text-[#d1f0d4] transition-colors">
                    Dashboard
                  </Link>
                  <Link href="/sesiones" className="text-white text-lg hover:text-[#d1f0d4] transition-colors">
                    Sesiones
                  </Link>
                  {isSuperUser && (
                    <Link href="/admin-panel" className="text-white text-lg hover:text-[#d1f0d4] transition-colors">
                      Admin
                    </Link>
                  )}
                </div>

                {/* Dropdown usuario */}
                <div className="relative" ref={dropdownRef}>
                  <div
                    className="flex items-center space-x-2 cursor-pointer"
                    onClick={() => setDropdownOpen(!dropdownOpen)}
                  >
                    <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white flex items-center justify-center text-[#00A240] font-bold text-lg md:text-xl">
                      {username?.charAt(0).toUpperCase() || "?"}
                    </div>
                    <span className="hidden md:inline text-white font-medium text-lg">
                      {username}
                    </span>
                  </div>

                  {dropdownOpen && (
                    <div className="absolute right-0 mt-2 w-44 bg-white rounded-md shadow-lg z-50">
                      <button
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2.5 text-gray-800 hover:bg-[#d1f0d4] transition-colors"
                      >
                        Cerrar sesión
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

        {/* Menú móvil desplegable */}
        {menuOpen && isAuthenticated && (
          <div className="md:hidden mt-2 bg-white rounded-md shadow-lg text-gray-800 overflow-hidden">
            <Link
              href="/listacan"
              className="block px-4 py-3 border-b hover:bg-gray-50"
              onClick={() => setMenuOpen(false)}
            >
              Caninos
            </Link>
            <Link
              href="/dashboard"
              className="block px-4 py-3 border-b hover:bg-gray-50"
              onClick={() => setMenuOpen(false)}
            >
              Dashboard
            </Link>
            <Link
              href="/sesiones"
              className="block px-4 py-3 border-b hover:bg-gray-50"
              onClick={() => setMenuOpen(false)}
            >
              Sesiones Entrenamiento
            </Link>
            {isSuperUser && (
              <Link
                href="/admin-panel"
                className="block px-4 py-3 border-b hover:bg-gray-50"
                onClick={() => setMenuOpen(false)}
              >
                Admin Panel
              </Link>
            )}
          </div>
        )}
      </nav>
    </>
  );
}