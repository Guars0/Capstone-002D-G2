export default function Footer() {
  return (
    <footer className="w-full bg-[#00A240] text-white py-4 shrink-0">
      <div className="max-w-7xl mx-auto text-center">
        © {new Date().getFullYear()} SAG Caninos.
      </div>
    </footer>
  );
}