"use client";

import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useAuthStore } from "@/app/hooks/useAuthStore";

interface ProtectedRouteProps {
  children: React.ReactNode;
  adminOnly?: boolean;
}

export function ProtectedRoute({ children, adminOnly = false }: ProtectedRouteProps) {
  const { isAuthenticated, isSuperUser, isLoading } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (isLoading) return;
    if (pathname === "/login") return;

    if (!isAuthenticated) {
      router.replace("/login");
      return;
    }

    if (adminOnly && !isSuperUser) {
      router.replace("/");
      return;
    }
  }, [isLoading, isAuthenticated, isSuperUser, adminOnly, pathname, router]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="h-12 w-12 rounded-full border-4 border-[#328D56] border-t-transparent animate-spin"></div>
      </div>
    );
  }

  if (!isAuthenticated && pathname !== "/login") return null;

  if (adminOnly && !isSuperUser) return null;

  return <>{children}</>;
}
