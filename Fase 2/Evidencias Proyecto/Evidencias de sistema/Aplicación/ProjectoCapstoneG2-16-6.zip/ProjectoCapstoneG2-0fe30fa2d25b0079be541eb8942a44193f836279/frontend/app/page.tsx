"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import axiosInstance from "@/utils/AxiosInstance";
import dayjs from "dayjs";
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ProtectedRoute } from "@/app/components/ProtectedRoute";
import { useInView } from 'react-intersection-observer';

dayjs.extend(utc);
dayjs.extend(timezone);

interface Canino {
  id_canino: number;
  nombre: string;
  foto_can_base64?: string | null;
}

interface Sesion {
  id_sesion: number;
  canino: { id_canino: number; nombre: string };
  fase: { nombre: string } | null;
  aroma: { nombre: string } | null;
  entrenador: { nombres: string; apellidos: string } | null;
  fecha_ini_local: string;
  fecha_fin_local?: string;
  resultado?: string;
  puntuacion?: number;
  duracion_min?: number;
  observaciones?: string;
  video_url?: string | null;
}

export default function HomePage() {
  return (
    <ProtectedRoute>
      <HomePageContent />
    </ProtectedRoute>
  );
}

function HomePageContent() {
  const [loading, setLoading] = useState(true);
  const [sesiones, setSesiones] = useState<Sesion[]>([]);
  const [caninosMap, setCaninosMap] = useState<Map<number, Canino>>(new Map());
  const [videoDestacado, setVideoDestacado] = useState<string | null>(null);
  const [entrenamientoDestacado, setEntrenamientoDestacado] = useState<Sesion | null>(null);
  const { ref: proximosRef, inView: proximosInView } = useInView({ triggerOnce: true, threshold: 0.1 });

  const cargarDatos = useCallback(async () => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    try {
      setLoading(true);
      const [sesionesRes, caninosRes] = await Promise.all([
        axiosInstance.get("/sesiones/mias/", { signal: controller.signal }),
        axiosInstance.get("/caninos/", { signal: controller.signal })
      ]);

      const sesionesData = Array.isArray(sesionesRes.data) ? sesionesRes.data : [];
      const caninosData = Array.isArray(caninosRes.data) ? caninosRes.data : [];

      const map = new Map<number, Canino>();
      caninosData.forEach((c: Canino) => map.set(c.id_canino, c));
      setCaninosMap(map);
      setSesiones(sesionesData);

      const conVideo = sesionesData
        .filter((s: Sesion) => s.video_url)
        .sort((a: Sesion, b: Sesion) => new Date(b.fecha_ini_local).getTime() - new Date(a.fecha_ini_local).getTime());
      if (conVideo.length > 0) {
        setVideoDestacado(conVideo[0].video_url!);
        setEntrenamientoDestacado(conVideo[0]);
      }
    } catch (err: any) {
      if (err.name === 'CanceledError' || err.code === 'ERR_CANCELED') return;
      console.error("Error en carga:", err.message || err);
    } finally {
      clearTimeout(timeout);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (sesiones.length === 0 && caninosMap.size === 0) {
      cargarDatos();
    }
  }, [cargarDatos, sesiones.length, caninosMap.size]);

  const ahora = new Date();
  const hoyStr = dayjs(ahora).tz("America/Santiago").format("YYYY-MM-DD");
  
  const sesionesHoy = sesiones.filter(s => s.fecha_ini_local.startsWith(hoyStr));
  const proximasSesiones = sesiones
    .filter(s => new Date(s.fecha_ini_local) > ahora)
    .sort((a, b) => new Date(a.fecha_ini_local).getTime() - new Date(b.fecha_ini_local).getTime());

  const sesionesPorCanino = useMemo(() => {
    const map = new Map<number, { canino: Canino | null; sesiones: Sesion[] }>();
    proximasSesiones.forEach(s => {
      const id = s.canino.id_canino;
      const canino = caninosMap.get(id) || null;
      if (!map.has(id)) map.set(id, { canino, sesiones: [] });
      map.get(id)!.sesiones.push(s);
    });
    return Array.from(map.values());
  }, [proximasSesiones, caninosMap]);

  const formatoFecha = (iso: string) =>
    iso ? dayjs(iso).tz("America/Santiago").format("DD/MM HH:mm") : "";

  const getFotoUrl = (canino?: Canino | null) => {
    if (!canino || !canino.id_canino) return null;
    return `${process.env.NEXT_PUBLIC_DJANGO_URL}/api/caninos/${canino.id_canino}/foto/`;
  };

  return (
    <main className="min-h-screen bg-gray-50 p-3 sm:p-4">
      <div className="max-w-6xl mx-auto">
        {entrenamientoDestacado && (
          <section className="bg-white shadow-md rounded-xl p-4 mb-6">
            <h2 className="text-lg font-bold text-[#00A240] mb-3">Último entrenamiento destacado</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <video controls className="w-full rounded border" src={videoDestacado!} />
              </div>
              <div className="text-sm text-gray-700">
                <p><strong>Canino:</strong> {entrenamientoDestacado.canino.nombre}</p>
                <p><strong>Entrenador:</strong> {entrenamientoDestacado.entrenador?.nombres} {entrenamientoDestacado.entrenador?.apellidos}</p>
                <p><strong>Fase:</strong> {entrenamientoDestacado.fase?.nombre}</p>
                <p><strong>Inicio:</strong> {formatoFecha(entrenamientoDestacado.fecha_ini_local)}</p>
                <p><strong>Término:</strong> {formatoFecha(entrenamientoDestacado.fecha_fin_local || "")}</p>
                {entrenamientoDestacado.observaciones && (
                  <p className="italic text-gray-600">“{entrenamientoDestacado.observaciones}”</p>
                )}
              </div>
            </div>
          </section>
        )}

        <section className="mb-8">
          <h2 className="text-xl font-bold text-[#00A240] mb-4">Entrenamientos hoy</h2>
          {loading ? (
            <div className="text-center py-6 text-gray-600">Cargando...</div>
          ) : sesionesHoy.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-6 text-center text-gray-500">
              No hay entrenamientos para hoy.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {sesionesHoy.map(s => {
                const canino = caninosMap.get(s.canino.id_canino);
                const fotoUrl = getFotoUrl(canino);
                return (
                  <article key={s.id_sesion} className="bg-white rounded shadow p-3">
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gray-100 overflow-hidden">
                        {fotoUrl ? (
                          <img
                            src={fotoUrl}
                            alt={s.canino.nombre}
                            width={48}
                            height={48}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <span className="text-xl">🐶</span>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-800">{s.canino.nombre}</h3>
                        <p className="text-xs text-gray-600 mt-1">
                          🕒 {formatoFecha(s.fecha_ini_local)} – {formatoFecha(s.fecha_fin_local || "")}
                        </p>
                        {s.fase && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-indigo-100 text-indigo-800 mt-1">
                            {s.fase.nombre}
                          </span>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>

        <section ref={proximosRef}>
          <h2 className="text-xl font-bold text-[#00A240] mb-4">Próximos entrenamientos</h2>
          {loading ? (
            <div className="text-center py-6 text-gray-600">Cargando...</div>
          ) : sesionesPorCanino.length === 0 ? (
            <div className="bg-white rounded-xl shadow p-6 text-center text-gray-500">
              No hay entrenamientos programados próximamente.
            </div>
          ) : !proximosInView ? (
            <div className="space-y-4">
              {[...Array(Math.min(3, sesionesPorCanino.length))].map((_, i) => (
                <div key={i} className="bg-white rounded-xl shadow animate-pulse">
                  <div className="p-4 -b flex items-center gap-4">
                    <div className="w-24 h-24 bg-gray-200 rounded-xl" />
                    <div className="h-6 bg-gray-200 rounded w-32" />
                  </div>
                  <div className="p-4 space-y-3">
                    {[1, 2].map(j => (
                      <div key={j} className="flex items-start gap-3 p-3 bg-gray-100 rounded-lg">
                        <div className="w-3 h-3 bg-gray-300 rounded-full mt-2"></div>
                        <div className="flex-1 space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-24"></div>
                          <div className="flex gap-2">
                            <div className="h-5 bg-gray-200 rounded px-2 py-0.5 w-16"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-8">
              {sesionesPorCanino.map(({ canino, sesiones }) => {
                const fotoUrl = canino ? getFotoUrl(canino) : null;
                return (
                  <div key={canino?.id_canino || sesiones[0].id_sesion} className="bg-white rounded-xl shadow ">
                    <div className="p-4 ">
                      <div className="flex items-center gap-4">
                        <div className="flex-shrink-0 w-24 h-24 rounded-xl bg-gray-100 overflow-hidden">
                          {fotoUrl ? (
                            <img
                              src={fotoUrl}
                              alt={canino?.nombre || "Canino"}
                              width={96}
                              height={96}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gray-200">
                              <span className="text-3xl">🐾</span>
                            </div>
                          )}
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-gray-800">{canino?.nombre || "Sin nombre"}</h3>
                          {sesiones[0]?.fase && (
                            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 mt-1">
                              {sesiones[0].fase.nombre}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="space-y-3">
                        {sesiones.map(s => (
                          <div key={s.id_sesion} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                            <div className="flex-shrink-0 w-3 h-3 rounded-full bg-[#00A240] mt-2"></div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-800">
                                {formatoFecha(s.fecha_ini_local)}
                                {s.fecha_fin_local && ` → ${formatoFecha(s.fecha_fin_local)}`}
                              </p>
                              <div className="flex flex-wrap gap-2 mt-2">
                                {s.fase && (
                                  <span className="text-xs px-2 py-0.5 bg-indigo-100 text-indigo-800 rounded">
                                    {s.fase.nombre}
                                  </span>
                                )}
                                {s.aroma && (
                                  <span className="text-xs px-2 py-0.5 bg-amber-100 text-amber-800 rounded">
                                    {s.aroma.nombre}
                                  </span>
                                )}
                                {s.resultado && (
                                  <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 rounded">
                                    {s.resultado}
                                  </span>
                                )}
                                {s.puntuacion !== undefined && (
                                  <span className="text-xs px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded">
                                    ⭐ {s.puntuacion}/10
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}