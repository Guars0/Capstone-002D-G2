"use client";

import { useEffect, useState, useRef, useCallback } from "react";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import timezone from "dayjs/plugin/timezone";
import {
  crearSesion,
  obtenerSesiones,
  actualizarSesion,
  eliminarSesion
} from "@/utils/sesionesService";
import axiosInstance from "@/utils/AxiosInstance";
import { useAuthStore } from "@/app/hooks/useAuthStore";

dayjs.extend(utc);
dayjs.extend(timezone);

interface Canino {
  id_canino: number;
  nombre: string;
  entrenador_actual?: { id_entrenador: number } | null;
}

interface Entrenador {
  id_entrenador: number;
  nombres: string;
  apellidos: string;
}

interface Fase {
  id_fase: number;
  nombre: string;
}

interface Aroma {
  id_aroma: number;
  nombre: string;
}

interface SesionEntrenamiento {
  id_sesion: number;
  fecha_ini: string;
  fecha_fin: string;
  observaciones: string;
  video_url?: string | null; 
  duracion_min?: number | null;
  resultado?: string | null;
  puntuacion?: number | null;
  canino: Canino;
  entrenador: Entrenador;
  fase?: Fase;
  aroma?: Aroma;
}

export default function SesionesPage() {
  const { isAuthenticated } = useAuthStore();

  const [sesiones, setSesiones] = useState<SesionEntrenamiento[]>([]);
  const [caninos, setCaninos] = useState<Canino[]>([]);
  const [entrenadores, setEntrenadores] = useState<Entrenador[]>([]);
  const [fases, setFases] = useState<Fase[]>([]);
  const [aromas, setAromas] = useState<Aroma[]>([]);

  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState({
    fecha_ini_fecha: "",
    fecha_ini_hora: "",
    fecha_fin_fecha: "",
    fecha_fin_hora: "",
    id_canino: "",
    id_entrenador: "",
    id_fase: "",
    id_aroma: "",
    observaciones: "",
    duracion_min: "",
    resultado: "",
    puntuacion: "",
    video: null as File | null,
  });

  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const cargarSesiones = useCallback(async () => {
    if (!isAuthenticated) return;

    setLoading(true);
    try {
      const data = await obtenerSesiones();
      const normalizadas = data.map((s: any) => ({
        ...s,
        fecha_ini: s.fecha_ini_local || s.fecha_ini,
        fecha_fin: s.fecha_fin_local || s.fecha_fin,
      }));
      setSesiones(normalizadas);
    } catch (err) {
      console.error("Error al cargar sesiones:", err);
      setSesiones([]);
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  const cargarOpciones = useCallback(async () => {
    if (!isAuthenticated) return;

    try {
      const [c, e, f, a] = await Promise.all([
        axiosInstance.get("/caninos/"),
        axiosInstance.get("/entrenadores/"),
        axiosInstance.get("/fases/"),
        axiosInstance.get("/aromas/"),
      ]);

      setCaninos(c.data);
      setEntrenadores(e.data);
      setFases(f.data);
      setAromas(a.data);
    } catch (err) {
      console.error("Error al cargar opciones:", err);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (isAuthenticated) {
      cargarSesiones();
      cargarOpciones();
    }
  }, [isAuthenticated, cargarSesiones, cargarOpciones]);

  const fetchSesionHints = async (caninoId: number) => {
    setLoading(true);
    try {
      const resCanino = await axiosInstance.get(`/caninos/${caninoId}/`);
      const entrenadorId = resCanino.data.entrenador_actual?.id_entrenador;

      const resSesiones = await axiosInstance.get("/sesiones/mias/", {
        params: { canino_id: caninoId, ordering: "-fecha_ini", page_size: 1 },
      });
      const sesiones = Array.isArray(resSesiones.data) ? resSesiones.data : resSesiones.data.results || [];
      const ultimaSesion = sesiones[0];

      setForm((prev) => ({
        ...prev,
        id_entrenador: entrenadorId ? String(entrenadorId) : "",
        id_fase: ultimaSesion?.fase?.id_fase ? String(ultimaSesion.fase.id_fase) : "",
        id_aroma: ultimaSesion?.aroma?.id_aroma ? String(ultimaSesion.aroma.id_aroma) : "",
        fecha_ini_fecha: dayjs().tz("America/Santiago").format("YYYY-MM-DD"),
        fecha_ini_hora: dayjs().tz("America/Santiago").format("HH:mm"),
        fecha_fin_fecha: dayjs().tz("America/Santiago").format("YYYY-MM-DD"),
        fecha_fin_hora: dayjs().tz("America/Santiago").add(30, "minute").format("HH:mm"),
      }));
    } catch (err) {
      console.warn("No se pudieron cargar sugerencias:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, files } = e.target as any;
    setForm((prev) => ({ ...prev, [name]: files ? files[0] : value }));
    setSubmitError(null);

    if (name === "id_canino" && value && !editingId) {
      fetchSesionHints(Number(value));
    }
  };

  const handleHoraChange = (e: React.ChangeEvent<HTMLInputElement>, campo: "fecha_ini_hora" | "fecha_fin_hora") => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 4) value = value.slice(0, 4);
    if (value.length >= 3) value = `${value.slice(0, 2)}:${value.slice(2)}`;
    setForm((prev) => ({ ...prev, [campo]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setLoading(true);

    if (!form.fecha_ini_fecha || !form.fecha_ini_hora) {
      setSubmitError("La fecha y hora de inicio son obligatorias.");
      setLoading(false);
      return;
    }
    if (!form.id_canino || !form.id_entrenador) {
      setSubmitError("Debe seleccionar un canino y un entrenador.");
      setLoading(false);
      return;
    }

    const formData = new FormData();
    formData.append("canino_id", form.id_canino);
    formData.append("entrenador_id", form.id_entrenador);
    if (form.id_fase) formData.append("fase_id", form.id_fase);
    if (form.id_aroma) formData.append("aroma_id", form.id_aroma);
    formData.append("fecha_ini_input", `${form.fecha_ini_fecha}T${form.fecha_ini_hora}:00`);
    if (form.fecha_fin_fecha && form.fecha_fin_hora) {
      formData.append("fecha_fin_input", `${form.fecha_fin_fecha}T${form.fecha_fin_hora}:00`);
    }
    if (form.observaciones) formData.append("observaciones", form.observaciones);
    if (form.video) formData.append("video", form.video);
    if (form.duracion_min) formData.append("duracion_min", form.duracion_min);
    if (form.resultado) formData.append("resultado", form.resultado);
    if (form.puntuacion) formData.append("puntuacion", form.puntuacion);

    try {
      if (editingId) {
        await actualizarSesion(editingId, formData);
        await cargarSesiones(); 
      } else {
        const res = await crearSesion(formData);
        const nuevaSesion: SesionEntrenamiento = {
          ...res,
          fecha_ini: res.fecha_ini_local || res.fecha_ini,
          fecha_fin: res.fecha_fin_local || res.fecha_fin,
          video_url: res.video_url || null,
        };
        setSesiones((prev) => [nuevaSesion, ...prev]);
      }

      setForm({
        fecha_ini_fecha: "",
        fecha_ini_hora: "",
        fecha_fin_fecha: "",
        fecha_fin_hora: "",
        id_canino: "",
        id_entrenador: "",
        id_fase: "",
        id_aroma: "",
        observaciones: "",
        video: null,
        duracion_min: "",
        resultado: "",
        puntuacion: "",
      });
      setEditingId(null);
    } catch (error: any) {
      console.error("Error al guardar sesión:", error);
      setSubmitError(
        error.response?.data?.detail ||
        error.response?.data?.message ||
        error.message ||
        "Error al guardar la sesión."
      );
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (s: SesionEntrenamiento) => {
    const fechaIni = dayjs(s.fecha_ini);
    const fechaFin = s.fecha_fin ? dayjs(s.fecha_fin) : null;

    setEditingId(s.id_sesion);
    setForm({
      fecha_ini_fecha: fechaIni.format("YYYY-MM-DD"),
      fecha_ini_hora: fechaIni.format("HH:mm"),
      fecha_fin_fecha: fechaFin ? fechaFin.format("YYYY-MM-DD") : "",
      fecha_fin_hora: fechaFin ? fechaFin.format("HH:mm") : "",
      id_canino: s.canino.id_canino.toString(),
      id_entrenador: s.entrenador.id_entrenador.toString(),
      id_fase: s.fase?.id_fase.toString() || "",
      id_aroma: s.aroma?.id_aroma.toString() || "",
      observaciones: s.observaciones || "",
      video: null,
      duracion_min: s.duracion_min?.toString() || "",
      resultado: s.resultado || "",
      puntuacion: s.puntuacion?.toString() || "",
    });
  };

  const handleCancel = () => {
    setEditingId(null);
    setForm({
      fecha_ini_fecha: "",
      fecha_ini_hora: "",
      fecha_fin_fecha: "",
      fecha_fin_hora: "",
      id_canino: "",
      id_entrenador: "",
      id_fase: "",
      id_aroma: "",
      observaciones: "",
      video: null,
      duracion_min: "",
      resultado: "",
      puntuacion: "",
    });
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("¿Seguro que desea eliminar esta sesión?")) return;

    try {
      await eliminarSesion(id);
      setSesiones((prev) => prev.filter((s) => s.id_sesion !== id));
    } catch (err) {
      alert("No se pudo eliminar la sesión");
      console.error("Error al eliminar:", err);
    }
  };

  const handleFileClick = () => fileInputRef.current?.click();

  const formatDateTime = (iso: string | null) => {
    if (!iso) return "—";
    const dt = dayjs(iso);
    return dt.isValid()
      ? dt.tz("America/Santiago").format("DD/MM/YYYY HH:mm")
      : "Fecha inválida";
  };

  return (
    <main className="p-4 sm:p-6 max-w-6xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">
          Sesiones de Entrenamiento
        </h1>
      </div>

      <section className="bg-white rounded-xl shadow-sm  mb-8 overflow-hidden">
        <div className="p-4 sm:p-6">
          <h2 className="text-xl font-semibold mb-4">
            {editingId ? "Editar sesión" : "Registrar nueva sesión"}
          </h2>

          {submitError && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
              {submitError}
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Fecha y hora de inicio <span className="text-red-500">*</span>
                  </label>
                  <div className="grid grid-cols-[1fr_auto] gap-2">
                    <input
                      type="date"
                      name="fecha_ini_fecha"
                      value={form.fecha_ini_fecha}
                      onChange={handleChange}
                      className="px-3 py-2 border border-gray-300 rounded-lg w-full"
                      required
                    />
                    <input
                      type="text"
                      name="fecha_ini_hora"
                      value={form.fecha_ini_hora}
                      onChange={(e) => handleHoraChange(e, "fecha_ini_hora")}
                      placeholder="hh:mm"
                      className="px-3 py-2 border border-gray-300 rounded-lg w-full text-center font-mono"
                      maxLength={5}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Fecha y hora de término
                  </label>
                  <div className="grid grid-cols-[1fr_auto] gap-2">
                    <input
                      type="date"
                      name="fecha_fin_fecha"
                      value={form.fecha_fin_fecha}
                      onChange={handleChange}
                      className="px-3 py-2 border border-gray-300 rounded-lg w-full"
                    />
                    <input
                      type="text"
                      name="fecha_fin_hora"
                      value={form.fecha_fin_hora}
                      onChange={(e) => handleHoraChange(e, "fecha_fin_hora")}
                      placeholder="hh:mm"
                      className="px-3 py-2 border border-gray-300 rounded-lg w-full text-center font-mono"
                      maxLength={5}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Canino <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="id_canino"
                    value={form.id_canino}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                    required
                  >
                    <option value="">Seleccione</option>
                    {caninos.map((c) => (
                      <option key={c.id_canino} value={c.id_canino}>
                        {c.nombre}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Entrenador <span className="text-red-500">*</span>
                  </label>
                  <select
                    name="id_entrenador"
                    value={form.id_entrenador}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                    required
                  >
                    <option value="">Seleccione</option>
                    {entrenadores.map((e) => (
                      <option key={e.id_entrenador} value={e.id_entrenador}>
                        {e.nombres} {e.apellidos}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Fase
                  </label>
                  <select
                    name="id_fase"
                    value={form.id_fase}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="">—</option>
                    {fases.map((f) => (
                      <option key={f.id_fase} value={f.id_fase}>
                        {f.nombre}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Aroma
                  </label>
                  <select
                    name="id_aroma"
                    value={form.id_aroma}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="">—</option>
                    {aromas.map((a) => (
                      <option key={a.id_aroma} value={a.id_aroma}>
                        {a.nombre}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Duración (min)
                  </label>
                  <input
                    type="number"
                    name="duracion_min"
                    value={form.duracion_min}
                    onChange={handleChange}
                    min={0}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Resultado
                  </label>
                  <input
                    type="text"
                    name="resultado"
                    value={form.resultado}
                    onChange={handleChange}
                    placeholder="Exitoso, Parcial..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Puntuación (1–10)
                  </label>
                  <input
                    type="number"
                    name="puntuacion"
                    value={form.puntuacion}
                    onChange={handleChange}
                    min={1}
                    max={10}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observaciones
                </label>
                <textarea
                  name="observaciones"
                  value={form.observaciones}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Video de la sesión
                </label>
                <button
                  type="button"
                  onClick={handleFileClick}
                  className="inline-flex items-center px-4 py-2.5 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700"
                >
                  {form.video ? "Cambiar video" : "Seleccionar video"}
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  name="video"
                  accept="video/*"
                  onChange={handleChange}
                  className="sr-only"
                />
                {form.video && (
                  <p className="mt-2 text-sm text-gray-600">
                    Video {form.video.name} ({(form.video.size / 1024 / 1024).toFixed(2)} MB)
                  </p>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-3 pt-6">
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2.5 bg-green-600 text-white font-medium rounded-md hover:bg-green-700 min-w-[120px] flex justify-center"
              >
                {loading ? (
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : editingId ? "Actualizar" : "Registrar"}
              </button>

              {editingId && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-5 py-2.5 bg-gray-200 text-gray-800 font-medium rounded-md hover:bg-gray-300 min-w-[120px]"
                >
                  Cancelar
                </button>
              )}
            </div>
          </form>
        </div>
      </section>

      <section>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Sesiones registradas</h2>
          <span className="text-sm text-gray-500">
            {loading ? "Cargando..." : `${sesiones.length} ${sesiones.length === 1 ? "sesión" : "sesiones"}`}
          </span>
        </div>

        {loading ? (
          <div className="flex justify-center py-8">
            <div className="h-8 w-8 rounded-full border-4 border-green-600 border-t-transparent animate-spin"></div>
          </div>
        ) : sesiones.length === 0 ? (
          <div className="bg-gray-50 rounded-lg p-6 text-center">
            <p className="text-gray-600">No hay sesiones registradas aún.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sesiones.map((s) => (
              <article key={s.id_sesion} className="bg-white rounded-lg  shadow-sm overflow-hidden">
                <div className="p-4">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mb-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      🐾 {s.canino.nombre}
                    </span>
                    {s.fase && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        {s.fase.nombre}
                      </span>
                    )}
                    {s.aroma && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                        {s.aroma.nombre}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm mb-3">
                    <dt className="font-medium text-gray-600">Entrenador:</dt>
                    <dd className="text-gray-900">{s.entrenador.nombres} {s.entrenador.apellidos}</dd>
                    <dt className="font-medium text-gray-600">Inicio:</dt>
                    <dd className="text-gray-900">{formatDateTime(s.fecha_ini)}</dd>
                    <dt className="font-medium text-gray-600">Término:</dt>
                    <dd className="text-gray-900">{formatDateTime(s.fecha_fin)}</dd>
                    {s.duracion_min && (
                      <>
                        <dt className="font-medium text-gray-600">Duración:</dt>
                        <dd className="text-gray-900">{s.duracion_min} min</dd>
                      </>
                    )}
                    {s.resultado && (
                      <>
                        <dt className="font-medium text-gray-600">Resultado:</dt>
                        <dd className="text-gray-900">{s.resultado}</dd>
                      </>
                    )}
                    {s.puntuacion && (
                      <>
                        <dt className="font-medium text-gray-600">Puntuación:</dt>
                        <dd className="text-gray-900">{s.puntuacion}/10</dd>
                      </>
                    )}
                  </div>

                  {s.observaciones && (
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <p className="text-sm text-gray-700">
                        <span className="font-medium text-gray-600">Observaciones:</span> {s.observaciones}
                      </p>
                    </div>
                  )}

                  {s.video_url && (
                    <div className="mt-3">
                      <video
                        src={s.video_url}
                        controls
                        className="w-full rounded border"
                        preload="metadata"
                      >
                        Tu navegador no soporta el elemento de video.
                      </video>
                    </div>
                  )}
                </div>

                <div className="border-t border-gray-100 bg-gray-50 px-4 py-3 flex gap-2 justify-end">
                  <button
                    onClick={() => handleEdit(s)}
                    className="px-3 py-1.5 text-sm font-medium text-yellow-700 bg-yellow-100 rounded hover:bg-yellow-200"
                  >
                    Editar
                  </button>

                  <button
                    onClick={() => handleDelete(s.id_sesion)}
                    className="px-3 py-1.5 text-sm font-medium text-red-700 bg-red-100 rounded hover:bg-red-200"
                  >
                    Eliminar
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}