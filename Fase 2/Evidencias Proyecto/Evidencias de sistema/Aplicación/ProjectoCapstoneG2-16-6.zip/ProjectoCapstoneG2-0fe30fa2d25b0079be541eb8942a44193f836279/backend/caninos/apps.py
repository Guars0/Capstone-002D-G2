from django.apps import AppConfig


class CaninosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caninos'
