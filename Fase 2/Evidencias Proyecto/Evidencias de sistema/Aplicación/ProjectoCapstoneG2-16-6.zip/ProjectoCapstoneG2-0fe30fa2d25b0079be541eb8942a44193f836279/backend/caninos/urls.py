from rest_framework import routers
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import *

router = DefaultRouter()
router.register(r'centros', CentroEntrenamientoViewSet, basename='centro')
router.register(r'estados-canino', EstadoCaninoViewSet, basename='estado-canino')
router.register(r'usuarios', UsuarioViewSet, basename='usuario')
router.register(r'entrenadores', EntrenadorViewSet, basename='entrenador')
router.register(r'caninos', CaninoViewSet, basename='canino')
router.register(r'fases', FaseEntrenamientoViewSet, basename='fase')
router.register(r'aromas', AromaViewSet, basename='aroma')
router.register(r'sesiones', SesionEntrenamientoViewSet, basename='sesion')
router.register(r'mensajes', MensajeViewSet, basename='mensaje')

urlpatterns = [
    path('', include(router.urls)),
]
