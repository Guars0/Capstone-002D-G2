import base64
from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import (
    CentroEntrenamiento, EstadoCanino, Usuario,
    Entrenador, Canino, FaseEntrenamiento, Aroma,
    SesionEntrenamiento, Mensaje
)
from django.utils.timezone import localtime

User = get_user_model()

class CentroEntrenamientoSerializer(serializers.ModelSerializer):
    class Meta:
        model = CentroEntrenamiento
        fields = ['id_centro', 'nombre_centro']

class EstadoCaninoSerializer(serializers.ModelSerializer):
    class Meta:
        model = EstadoCanino
        fields = ['id_estado', 'descripcion']

class UsuarioSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password', 'last_seen', 'is_staff', 'is_superuser']
        read_only_fields = ['last_seen']

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = User(**validated_data)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save()
        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        for k, v in validated_data.items():
            setattr(instance, k, v)
        if password:
            instance.set_password(password)
        instance.save()
        return instance

class EntrenadorSerializer(serializers.ModelSerializer):
    usuario = UsuarioSerializer(required=False, allow_null=True)
    foto_entrenador_base64 = serializers.SerializerMethodField(read_only=True)
    nueva_foto_entrenador_base64 = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = Entrenador
        fields = [
            'id_entrenador',
            'nombres',
            'apellidos',
            'estado',
            'email',
            'centro',
            'usuario',
            'foto_entrenador_base64',
            'nueva_foto_entrenador_base64',
        ]

    def get_foto_entrenador_base64(self, obj):
        if obj.foto_entrenador:
            try:
                data = bytes(obj.foto_entrenador)
                if data:
                    return base64.b64encode(data).decode('utf-8')
            except Exception as e:
                print(f"Error encoding foto_entrenador {obj.id_entrenador}: {e}")
        return None

    def create(self, validated_data):
        user_data = validated_data.pop('usuario', None)
        nueva_foto = validated_data.pop('nueva_foto_entrenador_base64', None)
        if nueva_foto:
            validated_data['foto_entrenador'] = base64.b64decode(nueva_foto)
        if user_data:
            user_serializer = UsuarioSerializer(data=user_data)
            user_serializer.is_valid(raise_exception=True)
            user = user_serializer.save()
        else:
            user = None
        return Entrenador.objects.create(usuario=user, **validated_data)

    def update(self, instance, validated_data):
        user_data = validated_data.pop('usuario', None)
        nueva_foto = validated_data.pop('nueva_foto_entrenador_base64', None)
        
        if nueva_foto:
            validated_data['foto_entrenador'] = base64.b64decode(nueva_foto)
        
        if 'email' in validated_data:
            instance.email = validated_data['email']
            if instance.usuario:
                instance.usuario.email = validated_data['email']
                instance.usuario.save(update_fields=['email'])
        
        if user_data:
            if instance.usuario:
                user_data.setdefault('email', instance.email)  # asegura consistencia
                usuario_ser = UsuarioSerializer(instance.usuario, data=user_data, partial=True)
                usuario_ser.is_valid(raise_exception=True)
                usuario_ser.save()
            else:
                user_data.setdefault('email', instance.email or "")
                instance.usuario = UsuarioSerializer().create(user_data)
                instance.save(update_fields=['usuario'])
        
        return super().update(instance, validated_data)
    

class CaninoSerializer(serializers.ModelSerializer):
    estado = EstadoCaninoSerializer(read_only=True)
    estado_id = serializers.PrimaryKeyRelatedField(
        queryset=EstadoCanino.objects.all(),
        source='estado',
        write_only=True,
        required=False
    )
    centro = CentroEntrenamientoSerializer(read_only=True)
    centro_id = serializers.PrimaryKeyRelatedField(
        queryset=CentroEntrenamiento.objects.all(),
        source='centro',
        write_only=True,
        required=False
    )
    entrenador_actual = EntrenadorSerializer(read_only=True)
    entrenador_actual_id = serializers.PrimaryKeyRelatedField(
        queryset=Entrenador.objects.all(),
        source="entrenador_actual",
        write_only=True,
        required=False,
        allow_null=True,
    )
    foto_can_base64 = serializers.SerializerMethodField(read_only=True)
    nueva_foto_can_base64 = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = Canino
        fields = [
            'id_canino',
            'fecha_nac',
            'nombre',
            'foto_can_base64',
            'nueva_foto_can_base64',
            'inicio_ent',
            'fin_ent',
            'estado',
            'estado_id',
            'centro',
            'centro_id',
            'entrenador_actual',
            'entrenador_actual_id',
        ]

    def get_foto_can_base64(self, obj):
        if obj.foto_can:
            try:
                data = bytes(obj.foto_can)
                if data:
                    return base64.b64encode(data).decode('utf-8')
            except Exception as e:
                print(f"Error encoding foto_can {obj.id_canino}: {e}")
        return None

    def create(self, validated_data):
        nueva_foto = validated_data.pop('nueva_foto_can_base64', None)
        if nueva_foto:
            validated_data['foto_can'] = base64.b64decode(nueva_foto)
        return super().create(validated_data)

    def update(self, instance, validated_data):
        nueva_foto = validated_data.pop('nueva_foto_can_base64', None)
        if nueva_foto:
            validated_data['foto_can'] = base64.b64decode(nueva_foto)
        return super().update(instance, validated_data)



class FaseEntrenamientoSerializer(serializers.ModelSerializer):
    class Meta:
        model = FaseEntrenamiento
        fields = ['id_fase', 'nombre']

class AromaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Aroma
        fields = ['id_aroma', 'tipo', 'nombre']

class SesionMinimaSerializer(serializers.ModelSerializer):
    canino = serializers.SerializerMethodField()
    entrenador = serializers.SerializerMethodField()
    fase = serializers.SerializerMethodField()
    aroma = serializers.SerializerMethodField()
    fecha_ini_local = serializers.DateTimeField(source='fecha_ini', format='%Y-%m-%dT%H:%M:%S%z', read_only=True)
    fecha_fin_local = serializers.DateTimeField(source='fecha_fin', format='%Y-%m-%dT%H:%M:%S%z', read_only=True)
    video_url = serializers.SerializerMethodField()

    class Meta:
        model = SesionEntrenamiento
        fields = [
            'id_sesion',
            'fecha_ini_local',
            'fecha_fin_local',
            'canino',
            'entrenador',
            'fase',
            'aroma',
            'duracion_min',
            'resultado',
            'puntuacion',
            'observaciones',
            'video_url'
        ]

    def get_canino(self, obj):
        return {
            'id_canino': obj.id_canino.id_canino,
            'nombre': obj.id_canino.nombre
        }

    def get_entrenador(self, obj):
        return {
            'id_entrenador': obj.id_entrenador.id_entrenador,
            'nombres': obj.id_entrenador.nombres,
            'apellidos': obj.id_entrenador.apellidos
        }

    def get_fase(self, obj):
        if obj.id_fase:
            return {'id_fase': obj.id_fase.id_fase, 'nombre': obj.id_fase.nombre}
        return None

    def get_aroma(self, obj):
        if obj.id_aroma:
            return {'id_aroma': obj.id_aroma.id_aroma, 'nombre': obj.id_aroma.nombre}
        return None

    def get_video_url(self, obj):
        if obj.video and hasattr(obj.video, 'url') and obj.video.url:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.video.url)
            return obj.video.url
        return None

class SesionEntrenamientoSerializer(serializers.ModelSerializer):
    canino = CaninoSerializer(source='id_canino', read_only=True)
    entrenador = EntrenadorSerializer(source='id_entrenador', read_only=True)
    fase = FaseEntrenamientoSerializer(source='id_fase', read_only=True)
    aroma = AromaSerializer(source='id_aroma', read_only=True)

    canino_id = serializers.PrimaryKeyRelatedField(
        queryset=Canino.objects.all(), source='id_canino', write_only=True
    )
    entrenador_id = serializers.PrimaryKeyRelatedField(
        queryset=Entrenador.objects.all(), source='id_entrenador', write_only=True
    )
    fase_id = serializers.PrimaryKeyRelatedField(
        queryset=FaseEntrenamiento.objects.all(), source='id_fase', write_only=True
    )
    aroma_id = serializers.PrimaryKeyRelatedField(
        queryset=Aroma.objects.all(),
        source='id_aroma',
        write_only=True,
        required=False,
        allow_null=True,
    )

    fecha_ini_input = serializers.DateTimeField(source='fecha_ini', write_only=True)
    fecha_fin_input = serializers.DateTimeField(source='fecha_fin', write_only=True)

    fecha_ini_local = serializers.DateTimeField(source='fecha_ini', read_only=True, format='%Y-%m-%dT%H:%M:%S%z')
    fecha_fin_local = serializers.DateTimeField(source='fecha_fin', read_only=True, format='%Y-%m-%dT%H:%M:%S%z')

    video_url = serializers.SerializerMethodField(read_only=True)
    video = serializers.FileField(write_only=True, required=False)

    class Meta:
        model = SesionEntrenamiento
        fields = [
            'id_sesion',
            'fecha_ini_local', 'fecha_fin_local',
            'fecha_ini_input', 'fecha_fin_input',
            'canino', 'canino_id',
            'entrenador', 'entrenador_id',
            'fase', 'fase_id',
            'aroma', 'aroma_id',
            'duracion_min',
            'resultado',
            'puntuacion',
            'observaciones',
            'video',
            'video_url',
        ]

    def get_video_url(self, obj):
        if obj.video and hasattr(obj.video, 'url') and obj.video.url:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.video.url)
            return obj.video.url
        return None

class MensajeSerializer(serializers.ModelSerializer):
    emisor = EntrenadorSerializer(source='id_emisor', read_only=True)
    emisor_id = serializers.PrimaryKeyRelatedField(queryset=Entrenador.objects.all(), source='id_emisor', write_only=True)
    receptor = EntrenadorSerializer(source='id_receptor', read_only=True)
    receptor_id = serializers.PrimaryKeyRelatedField(queryset=Entrenador.objects.all(), source='id_receptor', write_only=True)

    class Meta:
        model = Mensaje
        fields = ['id_msj', 'fecha_hora', 'texto', 'emisor', 'emisor_id', 'receptor', 'receptor_id']
    

class SesionLigeraSerializer(serializers.ModelSerializer):
    canino = serializers.SerializerMethodField()
    entrenador = serializers.SerializerMethodField()
    fase = serializers.SerializerMethodField()
    aroma = serializers.SerializerMethodField()

    fecha_ini_local = serializers.DateTimeField(
        source='fecha_ini', format='%Y-%m-%dT%H:%M:%S', read_only=True
    )
    fecha_fin_local = serializers.DateTimeField(
        source='fecha_fin', format='%Y-%m-%dT%H:%M:%S', read_only=True
    )

    class Meta:
        model = SesionEntrenamiento
        fields = [
            'id_sesion',
            'fecha_ini_local', 'fecha_fin_local',
            'canino', 'entrenador', 'fase', 'aroma',
            'duracion_min', 'resultado', 'puntuacion',
        ]

    def get_canino(self, obj):
        if not obj.id_canino:
            return None
        return {
            "id_canino": obj.id_canino.id_canino,
            "nombre": obj.id_canino.nombre,
            "estado": {"descripcion": obj.id_canino.estado.descripcion} if obj.id_canino.estado else None,
        }

    def get_entrenador(self, obj):
        if not obj.id_entrenador:
            return None
        return {
            "id_entrenador": obj.id_entrenador.id_entrenador,
            "nombres": obj.id_entrenador.nombres,
            "apellidos": obj.id_entrenador.apellidos,
        }

    def get_fase(self, obj):
        if not obj.id_fase:
            return None
        return {
            "id_fase": obj.id_fase.id_fase,
            "nombre": obj.id_fase.nombre,
        }

    def get_aroma(self, obj):
        if not obj.id_aroma:
            return None
        return {
            "id_aroma": obj.id_aroma.id_aroma,
            "nombre": obj.id_aroma.nombre,
        }
    
