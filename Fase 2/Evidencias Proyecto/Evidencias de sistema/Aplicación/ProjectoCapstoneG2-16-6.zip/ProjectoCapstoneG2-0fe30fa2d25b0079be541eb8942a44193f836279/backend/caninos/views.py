# caninos/views.py
from rest_framework import viewsets, filters, status
from .models import (
    CentroEntrenamiento, EstadoCanino, Usuario,
    Entrenador, Canino, FaseEntrenamiento, Aroma, SesionEntrenamiento, Mensaje
)
from .serializers import (
    CentroEntrenamientoSerializer, EstadoCaninoSerializer,
    UsuarioSerializer, EntrenadorSerializer, CaninoSerializer, FaseEntrenamientoSerializer,
    AromaSerializer, SesionEntrenamientoSerializer, MensajeSerializer, SesionLigeraSerializer
)
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Prefetch, F


class CentroEntrenamientoViewSet(viewsets.ModelViewSet):
    queryset = CentroEntrenamiento.objects.all()
    serializer_class = CentroEntrenamientoSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['nombre_centro']


class EstadoCaninoViewSet(viewsets.ModelViewSet):
    queryset = EstadoCanino.objects.all()
    serializer_class = EstadoCaninoSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['descripcion']

class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.all()
    serializer_class = UsuarioSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['username', 'email']

    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def me(self, request):
        serializer = self.get_serializer(request.user)
        return Response(serializer.data)

class EntrenadorViewSet(viewsets.ModelViewSet):
    queryset = Entrenador.objects.select_related('usuario', 'centro').all()
    serializer_class = EntrenadorSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['nombres', 'apellidos', 'email']
    def get_queryset(self):
        return super().get_queryset().order_by('nombres', 'apellidos')

    @action(detail=True, methods=['get'], url_path='foto', permission_classes=[AllowAny])
    def foto(self, request, pk=None):
        try:
            entrenador = self.get_object()
        except Entrenador.DoesNotExist:
            return HttpResponse(status=404)

        if not entrenador.foto_entrenador:
            return HttpResponse(status=404)

        try:
            data = bytes(entrenador.foto_entrenador)
            if not data:
                return HttpResponse(status=404)
        except Exception:
            return HttpResponse(status=404)

        return HttpResponse(
            data,
            content_type='image/jpeg',
            headers={
                'Cache-Control': 'public, max-age=604800',
                'Access-Control-Allow-Origin': 'http://localhost:3000',
                'Access-Control-Allow-Methods': 'GET',
            }
        )


class CaninoViewSet(viewsets.ModelViewSet):
    queryset = Canino.objects.select_related('estado', 'centro', 'entrenador_actual').all()
    serializer_class = CaninoSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['nombre']

    @action(detail=True, methods=['patch'], url_path='reasignar-entrenador')
    def reasignar_entrenador(self, request, pk=None):
        canino = self.get_object()
        entrenador_id = request.data.get('entrenador_id')
        
        if entrenador_id is None:
            canino.entrenador_actual = None
        else:
            try:
                entrenador = Entrenador.objects.get(id_entrenador=entrenador_id)
                canino.entrenador_actual = entrenador
            except Entrenador.DoesNotExist:
                return Response(
                    {"error": "Entrenador no encontrado"},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        canino.save()
        return Response(CaninoSerializer(canino).data)

    @action(detail=True, methods=['get'], url_path='foto', permission_classes=[AllowAny])
    def foto(self, request, pk=None):
        try:
            canino = self.get_object()
        except Canino.DoesNotExist:
            return HttpResponse(status=404)

        if not canino.foto_can:
            return HttpResponse(status=404)

        try:
            if hasattr(canino.foto_can, 'tobytes'):
                data = canino.foto_can.tobytes()
            else:
                data = bytes(canino.foto_can)
            
            if not data:
                return HttpResponse(status=404)
        except Exception:
            return HttpResponse(status=404)

        return HttpResponse(
            data,
            content_type='image/jpeg',
            headers={
                'Cache-Control': 'public, max-age=604800',
                'Access-Control-Allow-Origin': 'http://localhost:3000',
                'Access-Control-Allow-Methods': 'GET',
            }
        )

    @action(detail=False, methods=['post'], permission_classes=[AllowAny])
    def ids(self, request):
        ids = request.data.get('ids', [])
        if not isinstance(ids, list):
            ids = []

        valid_ids = []
        for i in ids:
            try:
                valid_ids.append(int(i))
            except (ValueError, TypeError):
                continue

        if not valid_ids:
            return Response([])

        caninos = Canino.objects.filter(id_canino__in=valid_ids).select_related(
            'estado', 'entrenador_actual'
        ).only(
            'id_canino', 'nombre',
            'estado__descripcion',
            'fecha_nac', 'inicio_ent', 'fin_ent',
            'entrenador_actual__id_entrenador',
            'entrenador_actual__nombres',
            'entrenador_actual__apellidos',
        )

        result = []
        for c in caninos:
            entrenador = None
            if c.entrenador_actual:
                entrenador = {
                    "id_entrenador": c.entrenador_actual.id_entrenador,
                    "nombres": c.entrenador_actual.nombres,
                    "apellidos": c.entrenador_actual.apellidos
                }
            result.append({
                "id_canino": c.id_canino,
                "nombre": c.nombre,
                "estado": {"descripcion": c.estado.descripcion} if c.estado else None,
                "fecha_nac": c.fecha_nac,
                "inicio_ent": c.inicio_ent,
                "fin_ent": c.fin_ent,
                "entrenador_actual": entrenador
            })
        return Response(result)
    
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def dashboard(self, request):
        """Endpoint optimizado para dashboard: devuelve todos los caninos sin filtrar por entrenador."""
        caninos = Canino.objects.select_related(
            'estado', 'entrenador_actual'
        ).only(
            'id_canino', 'nombre',
            'estado__descripcion',
            'fecha_nac', 'inicio_ent', 'fin_ent',
            'entrenador_actual__id_entrenador',
            'entrenador_actual__nombres',
            'entrenador_actual__apellidos',
        ).all()[:100]  
        
        serializer = self.get_serializer(caninos, many=True)
        return Response(serializer.data)

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context


class FaseEntrenamientoViewSet(viewsets.ModelViewSet):
    queryset = FaseEntrenamiento.objects.all()
    serializer_class = FaseEntrenamientoSerializer


class AromaViewSet(viewsets.ModelViewSet):
    queryset = Aroma.objects.all()
    serializer_class = AromaSerializer


class SesionEntrenamientoViewSet(viewsets.ModelViewSet):
    queryset = (
        SesionEntrenamiento.objects
        .select_related('id_canino', 'id_entrenador', 'id_fase', 'id_aroma')
        .defer('video')  
        .order_by('-fecha_ini')
    )
    serializer_class = SesionEntrenamientoSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = [
        'id_canino__nombre',
        'id_entrenador__nombres',
        'id_entrenador__apellidos',
        'id_fase__nombre',
        'id_aroma__nombre',
        'resultado',
    ]

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['request'] = self.request
        return context

    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def mias(self, request):
        from django.core.exceptions import ObjectDoesNotExist
        try:
            entrenador = request.user.entrenador
        except ObjectDoesNotExist:
            return Response([])

        sesiones = SesionEntrenamiento.objects.filter(
            id_entrenador=entrenador
        ).select_related(
            'id_canino', 'id_entrenador', 'id_fase', 'id_aroma'
        ).only(
            'id_sesion',
            'fecha_ini',
            'fecha_fin',
            'duracion_min',
            'resultado',
            'puntuacion',
            'observaciones',
            'video',
            'id_canino__id_canino',
            'id_canino__nombre',
            'id_entrenador__id_entrenador',
            'id_entrenador__nombres',
            'id_entrenador__apellidos',
            'id_fase__id_fase',
            'id_fase__nombre',
            'id_aroma__id_aroma',
            'id_aroma__nombre',
        ).order_by('-fecha_ini')[:500]

        base_url = request.build_absolute_uri('/')[:-1] 
        resultado = []
        for s in sesiones:
            video_url = None
            if s.video:
                video_url = f"{base_url}/media/{s.video}"

            item = {
                "id_sesion": s.id_sesion,
                "fecha_ini_local": s.fecha_ini.isoformat() if s.fecha_ini else None,
                "fecha_fin_local": s.fecha_fin.isoformat() if s.fecha_fin else None,
                "duracion_min": s.duracion_min,
                "resultado": s.resultado,
                "puntuacion": s.puntuacion,
                "observaciones": s.observaciones,
                "canino": {
                    "id_canino": s.id_canino.id_canino,
                    "nombre": s.id_canino.nombre
                },
                "entrenador": {
                    "id_entrenador": s.id_entrenador.id_entrenador,
                    "nombres": s.id_entrenador.nombres,
                    "apellidos": s.id_entrenador.apellidos
                },
                "fase": {"id_fase": s.id_fase.id_fase, "nombre": s.id_fase.nombre} if s.id_fase else None,
                "aroma": {"id_aroma": s.id_aroma.id_aroma, "nombre": s.id_aroma.nombre} if s.id_aroma else None,
                "video_url": video_url
            }
            resultado.append(item)

        return Response(resultado)
    
    @action(detail=False, methods=['get'])
    def por_canino(self, request):
        canino_id = request.query_params.get('canino_id')
        if not canino_id or not canino_id.isdigit():
            return Response({"error": "canino_id inválido"}, status=400)
        
        sesiones = SesionEntrenamiento.objects.filter(
            id_canino_id=canino_id
        ).select_related(
            'id_entrenador', 'id_fase', 'id_aroma'
        ).only(
            'id_sesion', 'fecha_ini', 'fecha_fin', 'observaciones',
            'id_entrenador__nombres', 'id_entrenador__apellidos',
            'id_fase__nombre',
            'id_aroma__nombre',
            'video'
        ).order_by('-fecha_ini')
        
        base_url = request.build_absolute_uri('/')[:-1]
        data = []
        
        for s in sesiones:
            video_url = None
            if s.video:
                try:
                    video_url = request.build_absolute_uri(s.video.url)
                except:
                    video_url = f"{base_url}/media/{s.video.name}"
            
            data.append({
                "id_sesion": s.id_sesion,
                "fecha_ini": s.fecha_ini.isoformat() if s.fecha_ini else None,
                "fecha_fin": s.fecha_fin.isoformat() if s.fecha_fin else None,
                "observaciones": s.observaciones,
                "entrenador": {
                    "id_entrenador": s.id_entrenador.id_entrenador,
                    "nombre_completo": f"{s.id_entrenador.nombres} {s.id_entrenador.apellidos}"
                },
                "fase": {"nombre": s.id_fase.nombre} if s.id_fase else None,
                "aroma": {"nombre": s.id_aroma.nombre} if s.id_aroma else None,
                "video_url": video_url
            })
        
        return Response(data)
    
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def todos(self, request):
        """Endpoint SIMPLE y SEGURO que devuelve TODAS las sesiones sin formato complejo."""
        sesiones = SesionEntrenamiento.objects.select_related(
            'id_canino', 'id_entrenador', 'id_fase', 'id_aroma'
        ).defer('video').order_by('-fecha_ini')[:500]

        resultado = []
        for s in sesiones:
            item = {
                "id_sesion": s.id_sesion,
                "fecha_ini_local": s.fecha_ini.isoformat() if s.fecha_ini else None,
                "fecha_fin_local": s.fecha_fin.isoformat() if s.fecha_fin else None,
                "duracion_min": s.duracion_min,
                "resultado": s.resultado,
                "puntuacion": s.puntuacion,
                "canino": {
                    "id_canino": s.id_canino.id_canino,
                    "nombre": s.id_canino.nombre
                } if s.id_canino else None,
                "entrenador": {
                    "id_entrenador": s.id_entrenador.id_entrenador,
                    "nombres": s.id_entrenador.nombres,
                    "apellidos": s.id_entrenador.apellidos
                } if s.id_entrenador else None,
                "fase": {
                    "id_fase": s.id_fase.id_fase,
                    "nombre": s.id_fase.nombre
                } if s.id_fase else None,
                "aroma": {
                    "id_aroma": s.id_aroma.id_aroma,
                    "nombre": s.id_aroma.nombre
                } if s.id_aroma else None
            }
            resultado.append(item)
        
        return Response(resultado)
    def get_serializer_class(self):
        if self.action == 'list':
            return SesionLigeraSerializer
        return SesionEntrenamientoSerializer 
    

class MensajeViewSet(viewsets.ModelViewSet):
    queryset = Mensaje.objects.select_related('id_emisor', 'id_receptor').all().order_by('-fecha_hora')
    serializer_class = MensajeSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['texto', 'id_emisor__nombres', 'id_receptor__nombres']
