from django.db import models
from django.conf import settings
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from django.contrib.auth.models import AbstractUser

class CentroEntrenamiento(models.Model):
    id_centro = models.AutoField(primary_key=True)
    nombre_centro = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre_centro


class EstadoCanino(models.Model):
    id_estado = models.AutoField(primary_key=True)
    descripcion = models.CharField(max_length=100)

    def __str__(self):
        return self.descripcion

class Usuario(AbstractUser):
    last_seen = models.DateTimeField(null=True, blank=True)

    def actualizar_actividad(self):
        self.last_seen = timezone.now()
        self.save(update_fields=['last_seen'])

class Entrenador(models.Model):
    id_entrenador = models.AutoField(primary_key=True)
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100)
    estado = models.CharField(max_length=50, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    centro = models.ForeignKey(CentroEntrenamiento, on_delete=models.SET_NULL, null=True, related_name='entrenadores')
    usuario = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='entrenador', null=True, blank=True)
    foto_entrenador = models.BinaryField(null=True, blank=True)

    def __str__(self):
        return f"{self.nombres} {self.apellidos}"

class Canino(models.Model):
    id_canino = models.AutoField(primary_key=True)
    fecha_nac = models.DateField(null=True, blank=True)
    nombre = models.CharField(max_length=100)
    foto_can = models.BinaryField(null=True, blank=True) 
    inicio_ent = models.DateField(null=True, blank=True)
    fin_ent = models.DateField(null=True, blank=True)
    estado = models.ForeignKey(EstadoCanino, on_delete=models.SET_NULL, null=True)
    centro = models.ForeignKey(CentroEntrenamiento, on_delete=models.SET_NULL, null=True)
    entrenador_actual = models.ForeignKey(
        Entrenador,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="caninos_asignados",
        help_text="Entrenador responsable actual del canino. Puede cambiar con el tiempo."
    )
    def __str__(self):
        return self.nombre

class FaseEntrenamiento(models.Model):
    id_fase = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Aroma(models.Model):
    id_aroma = models.AutoField(primary_key=True)
    tipo = models.CharField(max_length=100)
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.nombre} ({self.tipo})"
    
class SesionEntrenamiento(models.Model):
    id_sesion = models.AutoField(primary_key=True)
    fecha_ini = models.DateTimeField()
    fecha_fin = models.DateTimeField()
    id_canino = models.ForeignKey(Canino, on_delete=models.CASCADE)
    id_entrenador = models.ForeignKey(Entrenador, on_delete=models.CASCADE)
    id_fase = models.ForeignKey(FaseEntrenamiento, on_delete=models.SET_NULL, null=True)
    id_aroma = models.ForeignKey(Aroma, on_delete=models.SET_NULL, null=True)

    duracion_min = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Duración total aproximada de la sesión (minutos)"
    )
    resultado = models.CharField(
        max_length=50, blank=True, null=True,
        help_text="Ej: Exitoso, Parcial, Fallido"
    )
    puntuacion = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Desempeño general del canino (escala de 1 a 10)"
    )

    observaciones = models.TextField(blank=True, null=True)
    video = models.FileField(upload_to='videos/', blank=True, null=True)

    def __str__(self):
        return f"{self.id_canino.nombre} - {self.fecha_ini.strftime('%Y-%m-%d %H:%M')} ({self.resultado or 'Sin resultado'})"
    
    class Meta:
        indexes = [
            models.Index(
                fields=['id_entrenador', '-fecha_ini'],
                name='sesion_entrenador_fecha_desc'
            ),
        ]

class Mensaje(models.Model):
    id_msj = models.AutoField(primary_key=True)
    fecha_hora = models.DateTimeField(default=timezone.now)
    texto = models.TextField()
    id_emisor = models.ForeignKey(Entrenador, on_delete=models.CASCADE, related_name='mensajes_enviados')
    id_receptor = models.ForeignKey(Entrenador, on_delete=models.CASCADE, related_name='mensajes_recibidos')

    def __str__(self):
        return f"Mensaje {self.id_msj} de {self.id_emisor} a {self.id_receptor}"
