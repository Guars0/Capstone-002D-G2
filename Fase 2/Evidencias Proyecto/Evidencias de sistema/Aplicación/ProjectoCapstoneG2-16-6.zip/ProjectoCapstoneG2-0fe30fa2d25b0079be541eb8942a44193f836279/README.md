# ProjectoCapstoneG2
INSTRUCCIONES
---
Requerimientos
---
Docker, Extensión Docker en VSCode
Git

Como iniciar el proyecto
1. Asegurarse de que Docker esté activo actualmente en Windows
2. (Configurar Git en caso de no haberlo hecho antes, correo, usuario etc.)
3. abrir terminal en la carpeta del proyecto
4. git clone {url_del_proyecto}
5. Crear archivo .env en carpeta del proyecto e ingresar lo siguiente:
      POSTGRES_DB=caninos
      POSTGRES_USER=projectonsag
      POSTGRES_PASSWORD=patatapataton
      POSTGRES_HOST=159.112.143.195
      POSTGRES_PORT=5432
6. Crear otro archivo .env.local dentro de la carpeta de frontend e ingresar lo siguiente:
      NEXT_PUBLIC_DJANGO_URL=http://localhost:8000
7. docker compose build (Instala dependencias del proyecto)
8. docker compose up (Arma el proyecto y lo ejecuta)
9. Listo
